﻿/*
Author: Ethan Huang
Email: yongjie989@gmail.com
- 1 inch = 2.54cm
- 1 pixel = 0.026cm
- 1 cm = 37.79 pixels
- 4 x 6 inch, typical display for computer screen is 72dpi,
  so, 4x6" is 4" x 72dpi = 288pixels; 6" x 72dpi = 432pixels.
  But sometime we want a much better resolution as printer. So typical suggest to 300dpi.
  So 4x6" is 4" x 300dpi = 1200pixels; 6" x 300dpi = 1800pixels.
- 300/72=4.17; When before output image we need to change canvas size:
  step 1 : modify width and height for the canvas using setHeight(canvas.getHeight() * 4.17)
  step 2 : modify width and height size, top and left position for each objects:
  var o = canvas.getObjects();
  o[index].scaleX *= 4.17;
  o[index].scaleY *= 4.17;
  o[index].top *= 4.17;
  o[index].left *= 4.17;
  ...
  canvas.toDataURL('png');
  
* 2013-09-11
  - database location at C:\Documents and Settings\THIS_USER\Local Settings\Application Data\Google\Chrome\User Data\Default\databases\file_***\ HERE!!
  - o.set({opacity:0, selectable: false}) and o.set({opacity:1, selectable: true})
  
	"mouse:down"
	"mouse:move"
	"mouse:up"

	"after:render"
	"before:selection:cleared"
	"selection:created"
	"selection:cleared"

	"object:modified"
	"object:selected"
	"object:moving"
	"object:scaling"
	"object:rotating"
	"object:added"
	"object:removed"
	
	[Get work list] When load in painter page.
	HandlerPainter.ashx?action=get_work_list&order_id=xx
	
	[Completed] When user click Completed button then send the action.
	HandlerPainter.ashx?action=finish_painter&order_detail_id=xx&painter_id=123456
	
	
* 2013-09-12
  - After changed the bring to forward and front position for object, here have detect here will change index position in canvas._objects at the same time.
    So, might create a new field called "layer_index" in table, and write index when add a new object.

*/

var active_object;
var newImage;
var active_font;
var display_min_width = 400;
var display_min_height = 275;
var display_width = screen.width - display_min_width;
var display_height = screen.height - display_min_height;
var finish_dialog;
var checkout_dialog;
var upload_dialog;

var canvas = new fabric.Canvas('c');
canvas.setWidth(display_width-18);
canvas.setHeight(display_height-18);
//canvas.setWidth(1600);
//canvas.setHeight(1200);
$("#mycanvas_base").css({'width':display_width,'height':display_height,'overflow-x':'scroll','overflow-y':'scroll'});
$("#separate_line").css({'width':display_width/2,'height':display_height});

draw_middle_line();

function draw_middle_line(){
	middle_canvas = document.getElementById("middle_canvas");
	$("#middle_canvas").css({'left':(display_width/2) + 'px'});
	middle_canvas.width  = 2;
	middle_canvas.height  = display_height-18;
	ctx = middle_canvas.getContext("2d");
	ctx.beginPath();
	ctx.moveTo(0, 0);
	ctx.lineTo(0, display_height);
	ctx.strokeStyle="blue";
	ctx.stroke();
};
document.onselectstart = function () { return false; };

function disableF5(e) {
    if ((e.which || e.keyCode) == 116)
        e.preventDefault();
};
$(document).bind("keydown", disableF5);

function deleteKey(e){
	if ((e.which || e.keyCode) == 46)
		delete_object();
};
$(document).bind("keydown", deleteKey);
function change_page(page) {
    $("#photos_page").hide();
    $("#text_page").hide();
    $("#material_page").hide();
    $("#mask_page").hide();
    $("#background_page").hide();
    $(page).show();


};

function setStorage(name, value, expires) {
    var date = new Date();
    var schedule = Math.round((date.setSeconds(date.getSeconds()+expires))/1000);
    localStorage.setItem(name, value);
    localStorage.setItem(name+'_time', schedule);
}

function getStorage(name){
	return localStorage.getItem(name);
}

function clearUserName() {
    localStorage.user_name = '';
    localStorage.before_login_url = '';
    return false;
}
function DeletePage(){
	if(confirm('確定要刪除頁面嗎?')){
		if(user_add_painter_pages == 0){
			alert('頁面不得小於' + painter_pages.toString() + '頁');
			return false;
		}
		if(user_add_painter_pages>0){
			user_add_painter_pages--;
			
			$("#pageid_"+page_id).remove();
			return false;
		}
		
	};
};

function NewPage(){
	user_add_painter_pages++;
	page_num = (painter_pages-1) + user_add_painter_pages;
	var p = '<div id="pageid_'+page_num+'">'+
		'<table>'+
		'<tr><td><img onclick="exchange_pages('+(page_num)+')" style="cursor:pointer;background-color:#ffffff;" src="painter/images/page.png" width="90" border="1"></td></tr>'+
		'<tr><td align="center">['+(page_num+1)+']</td></tr>'+
		'</table>'+
		'</div>';
	$("#pages_list").append(p);
    
};

function TemplateNewPage(){
	//template_save();
	user_add_painter_pages++;
	page_num = 0 + user_add_painter_pages;
	var p = '<div id="pageid_'+page_num+'">'+
		'<table>'+
		'<tr><td><img onclick="exchange_template_pages('+(page_num-1)+')" style="cursor:pointer;background-color:#ffffff;" src="painter/images/page.png" width="90" border="1"></td></tr>'+
		'<tr><td align="center">['+(page_num)+']</td></tr>'+
		'</table>'+
		'</div>';
	$("#pages_list").append(p);
	
	var json = {};
	json.painter_id = painter_id;
	//console.log('TemplateNewPage painter_id= ' + painter_id );
	var json = jQuery.parseJSON(JSON.stringify(json));
	$.ajax({
		type: 'POST',
		dataType: "json",
		url: 'HandlerPainter.ashx?action=addpage',
		data: json,
		success: function (data) {
            if (data.id == '999')
                alert(data.message);
        }
	});	
		
};
function TemplateDeletePage(){
	if(confirm('確定要刪除樣版頁面嗎?')){
		//template_save();
		if(user_add_painter_pages>0){
			user_add_painter_pages--;
			
			$("#pageid_"+(page_id+1)).remove();
			return false;
		}

		var json = {};
		json.painter_id = painter_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		$.ajax({
			type: 'POST',
			dataType: "json",
			url: 'HandlerPainter.ashx?action=delpage',
			data: json,
			success: function (data) {
                if (data.id == '999')
                    alert(data.message);
            }
		});			
	};
};

//$(document).ready(function () {
    
	/*
    $("#NewPage").click(function () {
        activate_detail = $("#NewPage_Detail");
        activate_detail.show();
        $("#toolbar_setup_panel").slideDown();

    });
    $("#close_toolbar_setup_panel_btn").click(function () {
        activate_detail.hide();
        $("#toolbar_setup_panel").slideUp();
    });
	*/
    
    


    
//});

function delete_object() {
	var o = canvas.getActiveObject();
    o.isdelete = 'Y';
	isdelete = true;
	record_step("刪除物件");

	//update database
	db.transaction(function(tx){
		//var sql = 'update history set isdelete="Y" where painter_id="'+painter_id+'" and object_index="'+o.id+'"; ';
		var sql = 'delete from history where painter_id="'+painter_id+'" and object_index="'+o.id+'"; ';
		//console.log(sql);
		tx.executeSql(sql, [], function(tx, results){
		});
	});
	
	
    //canvas.remove(o);
	o.visible = false;
	canvas.renderAll();
	close_layer_right_menu();
	$("#layer_list").find("div[id='layer_id_"+o.id+"']").hide();

};

function update_text(){
	var fill = '#000000';
	var stroke = '#000000';
	var fontWeight = 'normal';
	var font_Style = 'normal';
	var textDecoration = 'normal';
	if(fontColor != undefined){
		fill = fontColor
	};
	if(fontStrokeColor != undefined){
		stroke = fontStrokeColor
	};
	if(fontStyle != undefined){
		if(fontStyle == 'fontstyle_bold')
			fontWeight = 'bold';
		if(fontStyle == 'fontstyle_italic')
			font_Style = 'italic';
		if(fontStyle == 'fontstyle_under')
			textDecoration = 'underline';
	};

	var o = canvas.getActiveObject();
	o.text = $("#add_text").val();
	o.fontFamily = $('#fontSelect').fontSelector('selected');
	o.fontSize = parseInt($("#fontsize").val());
	o.fontWeight = fontWeight;
	o.fontStyle = font_Style;
	o.textDecoration = textDecoration;
	o.stroke = stroke;
	o.fill = fill;
	o.strokeWidth = parseInt($(fontStrokeWidth).val());
	canvas.renderAll()
};
function add_text() {
	var date = new Date();
	var id = date.getTime();
    var mytext = $("#add_text").val();
    var fontsize = $("#fontsize").val();
	
	var fill = '#000000';
	var stroke = '#000000';
	var fontWeight = 'normal';
	var font_Style = 'normal';
	var textDecoration = 'normal';
	if(fontColor != undefined){
		fill = fontColor
	};
	if(fontStrokeColor != undefined){
		stroke = fontStrokeColor
	};
	if(fontStyle != undefined){
		if(fontStyle == 'fontstyle_bold')
			fontWeight = 'bold';
		if(fontStyle == 'fontstyle_italic')
			font_Style = 'italic';
		if(fontStyle == 'fontstyle_under')
			textDecoration = 'underline';
	};

    var new_text = new fabric.Text(mytext, {
		id: id,
        fontFamily: active_font,
        fontSize: parseInt(fontsize),
		strokeWidth: parseInt($(fontStrokeWidth).val()),
		fill: fill,
		stroke: stroke,
		fontWeight: fontWeight,
		fontStyle: font_Style,
		textDecoration: textDecoration,
        left: 100,
        top: 100,
		originX:'left',
		originY:'top',
		output_pass: false,
		always_on_top: false,
        isdelete: 'N'
    });
	canvas.add(new_text);
	var o = canvas.getObjects();
	canvas.setActiveObject(o[o.length-1]);
	
	isnewfont = true;
	record_step('initial font');
	record_step('新增文字');
	add_layer();
	total_objects++;
	return false;
};

function zoomIn_middle_line(){
	middle_canvas = document.getElementById("middle_canvas");
	$("#middle_canvas").css({'left':(canvas.width/2) + 'px'});
	middle_canvas.width  = 2;
	middle_canvas.height  *= 1.5;
	ctx = middle_canvas.getContext("2d");
	ctx.beginPath();
	ctx.moveTo(0, 0);
	ctx.lineTo(0, middle_canvas.height);
	ctx.strokeStyle="blue";
	ctx.stroke();
};

function zoomOut_middle_line(){
	middle_canvas = document.getElementById("middle_canvas");
	$("#middle_canvas").css({'left':(canvas.width/2) + 'px'});
	middle_canvas.width  = 2;
	middle_canvas.height  /= 1.5;
	ctx = middle_canvas.getContext("2d");
	ctx.beginPath();
	ctx.moveTo(0, 0);
	ctx.lineTo(0, middle_canvas.height);
	ctx.strokeStyle="blue";
	ctx.stroke();
};

function zoomIn(){
    canvas.setWidth( canvas.width * 1.5 );
    canvas.setHeight( canvas.height * 1.5 );
    var o = canvas._objects;
    $.each(o, function(k,v){
        v.scaleX *= 1.5;
        v.scaleY *= 1.5;
        v.left *= 1.5;
        v.top *= 1.5;
        v.setCoords();
    });
    canvas.renderAll();
	zoomIn_middle_line();
	zoomout_count *= 1.5;
};

function zoomOut(){
    canvas.setWidth( canvas.width / 1.5 );
    canvas.setHeight( canvas.height / 1.5 );
    var o = canvas._objects;
    $.each(o, function(k,v){
        v.scaleX /= 1.5;
        v.scaleY /= 1.5;
        v.left /= 1.5;
        v.top /= 1.5;
        v.setCoords();
    });
    canvas.renderAll();
	zoomOut_middle_line();
	zoomout_count /= 1.5;
};
/*
function enlarge_object() {
    var o = canvas.getActiveObject();
    if (o.type == 'text') {
        var new_fontSize = o.get('fontSize') * 1.2;
        o.set('fontSize', new_fontSize);
        o.adjustPosition();
        canvas.renderAll();
        
        return false;
    };
    var new_width = o.getWidth() * 1.2;
    var new_height = o.getHeight() * 1.2;

    o.scaleX = 1.0;
    o.scaleY = 1.0;

    o.set({ width: new_width, height: new_height });
    o.adjustPosition();
    canvas.renderAll();
    isenlarge_object = true;
    record_step('放大');
};
*/
function decrease_object() {
    var o = canvas.getActiveObject();
    if (o.type == 'text') {
        var new_fontSize = o.get('fontSize') * 0.8;
        o.set('fontSize', new_fontSize);
        o.adjustPosition();
        canvas.renderAll();
        
        return false;
    };

    //console.log('width:' + o.getWidth());
    var new_width = o.getWidth() * 0.8;
    var new_height = o.getHeight() * 0.8;
    //console.log('width:' + new_width);

    o.scaleX = 1.0;
    o.scaleY = 1.0;

    o.set({ width: new_width, height: new_height });
    o.adjustPosition();
    canvas.renderAll();
    isdecrease_object = true;
    record_step('縮小');
};
/*
canvas.getObjects();
canvas.getObjects()[2];
canvas.getActiveObject();選取中的物件.

//取得圖片檔名
var ac = canvas.getActiveObject();
ac._originalImage.attributes.src.value;

//刪除選擇的物件
canvas.remove( canvas.getActiveObject() )

//移到最後層
canvas.sendToBack ( canvas.getActiveObject() )
//移到下一層
canvas.sendBackwards( canvas.getActiveObject() )
//移到上一層
canvas.bringToFront( canvas.getActiveObject() )
//移到最上層
canvas.bringForward( canvas.getActiveObject() )

//重新校正位置
//o.adjustPosition()

//取得圖片原本的大小
o.getOriginalSize().width
o.getOriginalSize().height

//修改字體
var o = canvas.getActiveObject()
o.set('fontFamily', '王漢宗特明體')
canvas.renderAll()

//Trigger Active Object
var o = canvas.getObjects()
canvas.setActiveObject(o[index])
選擇新加入的object
canvas.setActiveObject(o[o.length-1])

//背景
canvas.setBackgroundImage('painter/background/1.jpg', function(){ canvas.renderAll();})

*/

var real_output_area = new fabric.Rect({
  left: canvas.getWidth() / 2,
  top: canvas.getHeight() / 2,
  fill: 'none',
  width: canvas.getWidth() - 12,
  height: canvas.getHeight() - 12,
  strokeWidth: 2,
  selectable: false,
  strokeDashArray: [1, 1],
  stroke: '#000040',
  id: 'real_output_area',
  output_pass: true,
  always_on_top: true,
});
canvas.add(real_output_area);
/*
var middle_line = new fabric.Line([canvas.getWidth() / 2,0,canvas.getWidth() / 2,canvas.getHeight()], {
    fill: 'red',
    stroke: 'red',
    strokeWidth: 1,
    selectable: false,
	strokeDashArray: [2, 2],
	id: 'middle_line',
	output_pass: true,
	always_on_top: true
  });
canvas.add(middle_line);
*/
/*
var circle = new fabric.Circle({
    radius: 20, fill: 'green', left: 100, top: 100, angle: 45, id : canvas.getObjects().length
});
canvas.add(circle);

var triangle = new fabric.Triangle({
    width: 20, height: 30, fill: 'blue', left: 50, top: 50, id : canvas.getObjects().length
});
canvas.add(triangle);
*/


function move_background_apply_btn(o, img) {
    ////console.log(img);
    $("#apply_background_btn").css({
        'position': 'relative',
        'border': '1px solid #000000',
        'padding': '3px',
        'background-color': '#f2f2f2',
        'cursor': 'pointer',
        'top': o.top - 80,
        'left': o.left + 90
    }).click(function () {
        canvas.setBackgroundImage(img, function () { canvas.renderAll(); })
        background_image = img;
    });
};

function move_mask_apply_btn(o, img, width, height) {
    //console.log(img);
	$("#apply_mask_btn").unbind('click');
	$("#apply_mask_btn").css({
        'font-size': '10px',
        'position': 'relative',
        'border': '1px solid #000000',
        'padding': '3px',
        'background-color': '#f2f2f2',
        'cursor': 'pointer',
        'top': o.top - 80,
        'left': o.left - 10
    }).click(function(){
		apply_mask(img, width, height);
	});
	$("#open_mask_btn").unbind('click');
    $("#open_mask_btn").css({
		'font-size': '10px',
        'position': 'relative',
        'border': '1px solid #000000',
        'padding': '3px',
        'background-color': '#f2f2f2',
        'cursor': 'pointer',
        'top': o.top - 80,
        'left': o.left + 90
    }).click(function () {
        open_mask_block(img, width, height);
    });
};


function close_init_box(){
    $("#init_box_block").hide();
};

function show_init_box() {
    $("#init_box_block").show();
    /*
    var c = url.parse(location.search);
    //console.log(c);
    var category = c.get.category;
    $("#init_inner_box").load("product.aspx?category=" + category);
    */
};

function checkout(){

    window.location.href = 'checkout.aspx?user_id=' + getStorage('user_id') + '&order_id=' + order_id + '&make_type=painter';

};

$("#Preview").click(function(){
	//console.log('click preview');
	show_init_box();
	$("#preview_inner_box").html('');
    var preview_html = '';
	$("#preview_block").show();
	var img = new Image();
	preview_html =  '<div class="slider-wrapper theme-dark"><div id="slider" class="nivoSlider">';
	for(var i = 0; i <= painter_pages; i++){
		var img = new Image();
		//\\10.1.53.149\doitwell02\upload\painter\painter\無框畫\3024001\輸出尺寸 120 x 150 cm 完成尺寸 110 x 140 cm_1901\preview\323_1901_1382580661840_0_.png
		img.src = 'upload/painter/'+session_name+'/'+product_type+'/'+confirm_order_detail_id+'/'+product_spec.replace("<br>"," ")+'_'+order_detail_id+'/preview/'+order_id+'_'+order_detail_id+'_'+painter_id+'_'+i+'_.png';
		//sleep(1000);
		//$("#dots").delay(2000);
		//if(img.height > 0){
			preview_html += '<img src="upload/painter/'+session_name+'/'+product_type+'/'+confirm_order_detail_id+'/'+product_spec.replace('<br>',' ')+'_'+order_detail_id+'/preview/'+order_id+'_'+order_detail_id+'_'+painter_id+'_'+i+'_.png" alt="" />';
		//};
		//console.log(img.src);
		//console.log(img.height);
	};
	
	preview_html += '</div></div>';
	preview_html += '<label style="cursor:pointer;float:right;color:#ffffff;" onclick="close_preview_block()">[關閉]</a></label>';
	preview_html += '<script type="text/javascript" src="painter/jquery.nivo.slider.js"></script>';
	//console.log(preview_html);
	$("#preview_inner_box").append(preview_html);
    jQuery(function(){
        $('#slider').nivoSlider({
            afterLoad: function(){
                //alert('afterload');
            }
        });
    });
	close_init_box();
});



function show_right_menu(x,y){
	close_right_menu();
	open_right_menu();
	$("#right_menu").css({"left":x+"px","top":y+"px"});
	
};

function show_layer_right_menu(x,y){
	close_layer_right_menu();
	open_layer_right_menu();
	$("#layer_right_menu").css({"left":x+"px","top":y+"px"});
	
};
function open_layer_right_menu(){
	$("#layer_right_menu").show();
};
function close_layer_right_menu(){
	$("#layer_right_menu").hide();
};

var cnv = document.getElementById('mycanvas_base');
cnv.oncontextmenu = function(env) {
	//console.log(env);
	var x = env.offsetX;
	var y = env.offsetY;
	////console.log(x+ '     ' + y);
	$.each(canvas._objects, function(k,v){
		// k>0, because we do not need choice "cut_area"
		if(k>0){
			if( (x >= v.left - v.width/2) && (x <= v.left + v.width/2) ){
				if( (y >= v.top - v.height/2) && (y <= v.top + v.height/2) ){
					//Why need check K > 0, because k = 0 is "Bleed".
					if(k>0){
						canvas.setActiveObject( canvas._objects[k] );
						
						if(canvas._objects[k].before_mask_image != undefined && canvas._objects[k].before_mask_image != "undefined")
							show_right_menu(env.pageX,env.pageY);
						////console.log(v);
						return false; 
					}
				};
			};
			close_right_menu();
		};			
	});
	return false; 
};

var layerlist_cnv = document.getElementById('layer_list');

if (layerlist_cnv != null){
	layerlist_cnv.oncontextmenu = function(env) {
		var active_id = env.target.id;
		var oid = active_id.split('_')
		oid = oid[oid.length-1];
		layer_div = $("#"+env.target.id);
		active_object_from_id(oid);
		show_layer_right_menu(layer_div.offset().left,env.pageY);
		return false; 
	};
};
function active_object_from_id(id){
    $.each(canvas._objects, function(k,v){
        if(v.id == id){
            canvas.setActiveObject( canvas._objects[k] );
            return false;
        }
        
    });
};

function open_right_menu(){
	$("#right_menu").show();
};
function close_right_menu(){
	$("#right_menu").hide();
};

function bring_forward(){
	canvas.bringForward( canvas.getActiveObject() );
	close_layer_right_menu();
	record_step('移到上一層');
	exchange_layer('bring_forward');
};

function object_infront(){
	canvas.bringToFront( canvas.getActiveObject() );
	close_layer_right_menu();
	record_step('移到最上層');
};

function bring_backward(){
	canvas.sendToBack ( canvas.getActiveObject() );
	close_layer_right_menu();
	record_step('移到最下層');
};

function object_behind(){
	canvas.sendBackwards( canvas.getActiveObject() );
	close_layer_right_menu();
	record_step('移到下一層');
	//console.log(this);
	exchange_layer('object_behind');
};

function exchange_layer(behavior){
	var o = canvas.getActiveObject();
	if (behavior == 'bring_forward'){
		$("#layer_list").find("div[id='layer_id_"+o.id+"']").insertBefore( $("#layer_list").find("div[id='layer_id_"+o.id+"']").prev("div") )
	}
	if (behavior == 'object_behind'){
		$("#layer_list").find("div[id='layer_id_"+o.id+"']").insertAfter( $("#layer_list").find("div[id='layer_id_"+o.id+"']").next("div") )
	}
};

var db = open_database();
create_database();
var product_type;
var product_spec;
var confirm_order_detail_id;
var painter_id;
var prod_id;
var session_name = getStorage('user_name');
var session_id = getStorage('user_id');
var order_id = get_order_id();
var order_detail_id;
var background_image;
var painter_width;
var painter_height;
var painter_pages;
var user_add_painter_pages = 0;
var page_id = 0;
var total_objects = 0;
var ismoving = false;
var isscaling = false;
var isrotating = false;
var isnewobject = false;
var isnewfont = false;
var isdelete = false;
var isenlarge_object = false;
var isdecrease_object = false;
var brightness_value = 0;
var opacity_value = 0;
var total_work_list = 0;
var not_yet_finish_work_list = 0;
var first_coming = true;
var drag_images;
var canvasContainer;
var zoomout_count = 1;

var ismax_redo_id = false;
var undo_id;
var redo_id;
var min_step_id;
var last_step_id;
var past_width;
var past_height;
var past_top;
var past_left;
var past_scaleX;
var past_scaleY;
var filter_array = new Array('image_filter_brightness','image_filter_blur','image_filter_sharpen','image_filter_emboss','image_filter_sepia');
var fontColor;
var fontStrokeColor;
var fontStyle;
var apply_template_record = new Array();

var real_height = 0;
var real_width = 0;
var real_bleed_height = 0;
var real_bleed_width = 0;

function get_order_id(){
	var c = url.parse(location.search);
	if (location.pathname == '/painter.html' || location.pathname == '/doitwell02/painter.html'){
		var order_id = c.get.order_id;
		return order_id;
	};
};

function open_database(){
	var db = openDatabase('painter_1.2.9','1.0','painter database', 1024 * 20);
	return db;
};

function create_database(){
	db.transaction(function(d){
		d.executeSql('create table IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT,painter_id integer,user_name text,layer_index integer, object_index integer, type text,top real,left real,width real,height real,selectable text,opacity real,scaleX real,scaleY real,fill text,radius real,angle real,stroke text,strokeWidth real,strokeDashArray text,filename text,action_function text,step_name text, isdelete text,filters text, before_mask_image text, fontText text, fontStyle text, textShadow text, fontWeight text, textDecoration text, step_id integer);');
	});
	db.transaction(function(d){
		d.executeSql("create table IF NOT EXISTS painter_manage(id INTEGER ,user_name text,createtime DATETIME DEFAULT (datetime('now','localtime')));");
	});

};

function get_painter_id(){
	var date = new Date();
	db.transaction(function(d){
		d.executeSql('insert into painter_manage (id, user_name) values ("'+date.getTime()+'", "'+session_name+'");');
	});
	db.transaction(function(d){
		d.executeSql('select max(id) as last_id from painter_manage where user_name ="'+session_name+'";', [], function(tx, results){
		painter_id = results.rows.item(0).last_id;
		$.getJSON('HandlerPainter.ashx?action=update_painter&order_detail_id='+order_detail_id+'&painter_id='+painter_id,{}, function(){});
		});
	});
};

function record_step(step_name){

	var o = canvas.getActiveObject();
	if (o.type == "image")
		filename = o._originalImage.attributes.src.value;
	else
		filename = "";
	var action_function = record_step.caller.name;
	if(ismoving == true)
		action_function = 'moving';
	if(isscaling == true)
		action_function = 'scaling';
	if(isrotating == true)
		action_function = 'rotating';
	if(isnewobject == true)
		action_function = 'new object';
	if(isnewfont == true)
		action_function = 'new font';
	if(isdelete == true)
		action_function = 'delete object';
	if(isenlarge_object == true)
		action_function = 'enlarge object';
	if(isdecrease_object == true)
		action_function = 'decrease object';
	
	if(step_name == 'initial')
		action_function = 'initial object';
	if(step_name == 'initial font')
		action_function = 'initial font';
    if(step_name == '新增物件')
		action_function = 'new object';
		
    var filters = '';
    if(step_name == 'Brightness'){
        filters = brightness_value;
    }
    if(step_name == 'Opacity'){
        filters = opacity_value;
    } 
    //var layer_index = canvas._objects.length-1;
    for(var i=0;i<canvas._objects.length;i++){
        ////console.log('canvas._objects[i].id = ' + canvas._objects[i].id + '   ' + 'o.id = ' + o.id);
        if(canvas._objects[i].id == o.id){
            var layer_index = i;
            break;
        }
    }
	
	var pw = past_width;
	//console.log('pw = ' + pw);
	//console.log('past_width = ' + past_width);
	//console.log('o.width = ' + o.width);
	var ph = past_height;
	var pt = past_top;
	var pl = past_left;
	var sx = past_scaleX;
	var sy = past_scaleY;
	
	if (pw == undefined)
		pw = o.width;
	if (ph == undefined)
		ph = o.height;
	if (pt == undefined)
		pt = o.top;
	if (pl == undefined)
		pl = o.left;
	if (sx != o.scaleX)
		sx = o.scaleX;
	if (sy != o.scaleY)
		sy = o.scaleY;
		
	//console.log('pw = ' + pw);

    var step_id = 1;
    db.transaction(function(tx){
	    var sql = 'select max(step_id) as id from history where painter_id="'+painter_id+'"; ';
	    tx.executeSql(sql, [], function(tx, results){
	            if(results.rows.length>0){
		            step_id = parseInt(results.rows.item(0).id) + 1;		
	            }
            });
	});

	var sql = 'insert into history (painter_id, user_name, layer_index, object_index, type, top, left, width, height, '+
	'selectable, opacity, scaleX, scaleY, fill, radius, angle, stroke, strokeWidth, strokeDashArray, filename, action_function, step_name,isdelete, filters, before_mask_image,fontText, fontStyle, textShadow, fontWeight, textDecoration, step_id)'+
	' values ("'+painter_id+'","'+session_name+'","'+layer_index+'","'+o.id+'","'+o.type+'","'+o.top+'","'+o.left+'","'+o.width+'","'+o.height+'", '+
	' "'+o.selectable+'","'+o.opacity+'", "'+o.scaleX+'", "'+o.scaleY+'", "'+o.fill+'", "'+o.radius+'", "'+o.angle+'", "'+o.stroke+'", '+
	' "'+o.strokeWidth+'", "'+o.strokeDashArray+'", "'+filename+'", "'+action_function+'", "'+step_name+'","N","'+filters+'","'+o.before_mask_image+'","'+o.text+'","'+o.fontStyle+'","'+o.textShadow+'","'+o.fontWeight+'","'+o.textDecoration+'","'+step_id+'" )';

    //console.log(sql);
	db.transaction(function(d){
		d.executeSql(sql);
	});
};

canvas.on('object:moving', function(options) {
	if (options.target) {
		ismoving = true;
	}
});
canvas.on('object:scaling', function(options) {
	if (options.target) {
		isscaling = true;
	}
});
canvas.on('object:rotating', function(options) {
	if (options.target) {
		isrotating = true;
	}
});
canvas.on('mouse:up', function(options) {
	close_right_menu();
	isnewobject = false;
	isnewfont = false;
	isdelete = false;
    isenlarge_object = false;
    isdecrease_object = false;
    
	//console.log('mouse:up');
	if (options.target && ismoving == true) {
		record_step('移動');
		//undo_id = undefined;
		//redo_id = undefined;
//		//console.log(options.target);
	}
	if (options.target && isscaling == true) {
		record_step('調整大小');
	}
	if (options.target && isrotating == true) {
		record_step('旋轉');
	}
	
	update_property_block();
	
	undo_id = undefined;
	redo_id = undefined;
	ismoving = false;
	isscaling = false;
	isrotating = false;
    close_work_list();
	//if (location.pathname != '/painter_template.html' && location.pathname != '/doitwell02/painter_template.html' )
	//	save();	

});

canvas.on('mouse:down', function(options) {
	//console.log('mouse:down');
	//past_width = options.target.width;
	//past_height = options.target.height;
	//past_top = options.target.top;
	//past_left = options.target.left;
	//past_scalX = options.target.scaleX;
	//past_scalY = options.target.scaleY;
	////console.log(options.target);
});
function update_property_block(){
	var o = canvas.getActiveObject();
	if(o) {
		if(o.type == 'text'){
			$("#add_text").val(o.text);
			$("#fontsize").val(o.fontSize);
			$('#fontSelect').find('span')[0].innerText = o.fontFamily;
			$('#fontSelect').attr('style','font-family: ' + o.fontFamily);
			if(o.fontWeight == 'bold')
				set_font_style('fontstyle_bold');
			if(o.fontStyle == 'italic')
				set_font_style('fontstyle_italic');
			if(o.textDecoration == 'underline')
				set_font_style('fontstyle_under');
			$("#colorSelector div").css({'background-color': o.fill});
			$("#colorSelector div").css({'background-color': o.sroke});
			$("#fontStrokeWidthSlider").slider('value', o.strokeWidth);
			$("#fontStrokeWidth").val(o.strokeWidth);
			//$('#fontSelect').find('span')[0].innerText = 'Flavors,Flavors';
			//$('#fontSelect').attr('style','font-family: Flavors,Flavors');
		};
		
		$("#property_width").val(o.width.toFixed(2));
		$("#property_height").val(o.height.toFixed(2));
		$("#property_left").val(o.left.toFixed(2));
		$("#property_top").val(o.top.toFixed(2));
	}
};

function get_min_step_id(callback){
db.transaction(function(tx){
	var sql = 'select min(id) as min_id from history where painter_id="'+painter_id+'"; '; //and isdelete="N"
	tx.executeSql(sql, [], function(tx, results){
	if(results.rows.length>0){
		//results.rows.item(0);
		////console.log('[*]min_step_id = ' + results.rows.item(0).min_id);
		callback(results.rows.item(0));
	}
	});
});
};

function get_last_step_id(callback){
db.transaction(function(tx){
	if(undo_id == undefined && redo_id == undefined)
		var sql = 'select max(id),* from history where painter_id="'+painter_id+'" ';
	else if(undo_id != undefined && redo_id == undefined)
		var sql = 'select * from history where painter_id="'+painter_id+'" and id<'+undo_id+' and step_id=1 order by id desc limit 1 ; ';
	else if(undo_id != undefined && redo_id != undefined){
		if(redo_id>undo_id){
			undo_id = redo_id;
			var sql = 'select * from history where painter_id="'+painter_id+'" and id<='+undo_id+' and step_id=1 order by id desc limit 1 ; ';
		}else if(redo_id == undo_id){
			var sql = 'select * from history where painter_id="'+painter_id+'" and id<'+undo_id+' and step_id=1 order by id desc limit 1 ; ';
		}
	}
	tx.executeSql(sql, [], function(tx, results){
	if(results.rows.length>0){
		//results.rows.item(0);
		callback(results.rows.item(0));
	}
	});
});
};


function undo(){
	
	get_min_step_id(function(callback){
		min_step_id = callback.min_id;
		console.log('[0]min_step_id = ' + min_step_id);
	});
	
	get_last_step_id(function(callback){
		undo_id = callback.id;
		console.log('[1]undo_id = ' + undo_id);
		
		//if (undo_id == undefined)
		//	undo_id = last_step_id;
		
		db.transaction(function(d){

			//if (undo_id > min_step_id)
			//	undo_id--;
			//console.log('undo_id = ' + undo_id);
            
			console.log('select * from history where painter_id="'+painter_id+'" and id<'+undo_id+' and step_id=1 order by id desc limit 1 ; ');
			d.executeSql('select * from history where painter_id="'+painter_id+'" and id<'+undo_id+' and step_id=1 order by id desc limit 1 ; ', [], function(tx, results){
				if(results.rows.length > 0){
					var o = results.rows.item(0);
					if(o.action_function == 'moving')
						undo_move(o);
					if(o.action_function == 'scaling')
						undo_scale(o);
					if(o.action_function == 'rotating')
						undo_rotate(o);
					if(o.action_function == 'initial object')
						undo_handleDrop(o);
					if(o.action_function == 'new object')
						undo_new_object(o);
					if(o.action_function == 'delete object')
						undo_delete_object(o);
					if(o.action_function == 'new font')
						undo_new_font(o);
					if(o.action_function == 'initial font')	
						undo_add_font(o);
					if(o.action_function == 'object_behind')
						undo_object_behind(o);
					if(o.action_function == 'bring_forward')
						undo_bring_forward(o);
					if(o.action_function == 'enlarge object')
						undo_enlarge_object(o);
					if(o.action_function == 'decrease object')
						undo_decrease_object(o);
                    if(filter_array.indexOf(o.action_function) != -1)
						undo_image_filters(o);
                    if(o.action_function == 'image_filter_opacity')
                        undo_image_filter_opacity(o);
					
					//console.log('o.action_function = ' + o.action_function);
					
					
					
					db.transaction(function(tx){
						tx.executeSql('update history set step_id=0 where painter_id="'+painter_id+'" and id = '+undo_id+' ; ', [], function(tx, results){
						});
					});

				}
			});
			
		});
		
		return true;
	});
	//redo_id = undefined;
	ismax_redo_id = false;
	
};
function redo(){
	run_redo();
	/*
	if (redo_id == undefined){
		redo_id = undo_id+1;
	}else if (redo_id < last_step_id){
			redo_id++;
	}
	*/
	//console.log('redo_id = ' + redo_id);
	/*
	if (ismax_redo_id == false)
		run_redo(redo_id);
	undo_id = undefined;
	if (redo_id == last_step_id){
		ismax_redo_id = true;
	}
	*/
};
/*
function undo(){
	db.transaction(function(d){
		if (undo_id == undefined)
			var sql = 'select max(id),* from history where painter_id="'+painter_id+'"; ';
		else
			var sql = 'select * from history where painter_id="'+painter_id+'" and id="'+undo_id+'"; ';
		d.executeSql(sql, [], function(tx, results){
			if(results.rows.length>0){
				get_undo_result(results.rows.item(0));
			}
		});
	});
};
*/
/*
function redo(){
	undo_id = undefined;
	if (redo_id == undefined)
		redo_id = undo_id+1;
	else
		redo_id++;
	direct_move(redo_id);

};
*/


function undo_move(o){
	////console.log('trigger undo_move');
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			
			
			break;
		};
	}; 
	undo_image_filters(o);
	/*
	return db.transaction(function(d){                
		        d.executeSql('delete from history where id="' + last_step_id + '"');
	});
	*/
};
function undo_scale(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();

            db.transaction(function(d){                
		        //d.executeSql('delete from history where id=\'' + last_step_id + '\'');
				//console.log('delete from history where id=\'' + last_step_id + '\'');
	        });
            
			break;
		};
	}; 
};

function undo_enlarge_object(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function undo_decrease_object(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};
function undo_rotate(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function undo_new_object(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			//next_o[i].set({top:o.top, left:o.left, width:o.width, height:o.height, scaleX:o.scaleX, scaleY:o.scaleY, angle:o.angle});
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
	//undo_image_filters(o);
	/*
	return db.transaction(function(d){                
		        d.executeSql('delete from history where id="' + last_step_id + '"');
	        });
	*/
};


function undo_handleDrop(o){
	if(confirm('確定刪除物件?刪除後將無法復原.')){
		db.transaction(function(tx){
			//var sql = 'update history set isdelete="Y" where painter_id="'+painter_id+'" and object_index="'+o.object_index+'"; ';
			var sql = 'delete from history where painter_id="'+painter_id+'" and object_index="'+o.object_index+'"; ';
			//console.log(sql);
			tx.executeSql(sql, [], function(tx, results){
			});
		});
		
		var next_o = canvas.getObjects();
		for(var i=0; i<= next_o.length-1; i++){
			if (next_o[i].id == o.object_index){
				canvas.setActiveObject( next_o[i] );
				//next_o[i].visible = false;
				next_o[i].remove();
				canvas.renderAll();
				break;
			};
		}; 
		//var remove_layer_index = (next_o.length-1);
		//$("#layer_list > div:eq("+remove_layer_index+")").hide();
		$("#layer_list").find("div[id='layer_id_"+o.object_index+"']").hide();
	}
};


function undo_delete_object(o){
    o.isdelete = 'N';
    isdelete = false;
	db.transaction(function(tx){
		var sql = 'update history set isdelete="N" where painter_id="'+painter_id+'" and object_index="'+o.object_index+'"; ';
		console.log(sql);
		tx.executeSql(sql, [], function(tx, results){
		});
	});
	
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].visible = true;
			canvas.renderAll();
			break;
		};
	}; 
	//var remove_layer_index = (next_o.length-1);
	//$("#layer_list > div:eq("+remove_layer_index+")").show();
	$("#layer_list").find("div[id='layer_id_"+o.object_index+"']").show();
};
function undo_new_font(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function undo_add_font(o){
	db.transaction(function(tx){
		var sql = 'update history set isdelete="Y" where painter_id="'+painter_id+'" and object_index="'+o.object_index+'"; ';
		//console.log(sql);
		tx.executeSql(sql, [], function(tx, results){
		});
	});
	
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].visible = false;
			canvas.renderAll();
			break;
		};
	}; 
	//var remove_layer_index = (next_o.length-1);
	//$("#layer_list > div:eq("+remove_layer_index+")").hide();
	$("#layer_list").find("div[id='layer_id_"+o.object_index+"']").hide();
};

function undo_object_behind(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			canvas.bringForward( next_o[i] );
			break;
		};
	}; 
};
function undo_bring_forward(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			canvas.sendBackwards( next_o[i] );
			break;
		};
	}; 
};

function undo_image_filters(o){
    var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
            next_o[i].filters.pop();
            next_o[i].applyFilters(canvas.renderAll.bind(canvas));
			break;
		};
	}; 
    undo_scale(o);
};

function undo_image_filter_opacity(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].set({opacity:1.0});
			next_o[i].adjustPosition();
			canvas.renderAll();
			break;
		};
	};  
};

function redo_move(o){
	////console.log('trigger redo_move');
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};
function redo_scale(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function redo_enlarge_object(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function redo_decrease_object(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};

function redo_rotate(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			next_o[i].top = o.top;
			next_o[i].left = o.left;
			next_o[i].width = o.width;
			next_o[i].height = o.height;
			next_o[i].scaleX = o.scaleX;
			next_o[i].scaleY = o.scaleY;
			next_o[i].angle = o.angle;
			next_o[i].adjustPosition();		
			next_o[i].originX = 'left';
			next_o[i].originY = 'top';
			canvas.renderAll();
			break;
		};
	}; 
};
function redo_object_behind(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			canvas.sendBackwards( next_o[i] );
			break;
		};
	}; 
};
function redo_bring_forward(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			canvas.bringForward( next_o[i] );
			break;
		};
	}; 
};

function redo_image_filter_opacity(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			image_filter_opacity(parseInt(o.filters), false);
			break;
		};
	}; 	
};

function redo_image_filter_brightness(o){
	var next_o = canvas.getObjects();
	for(var i=0; i<= next_o.length-1; i++){
		if (next_o[i].id == o.object_index){
			canvas.setActiveObject( next_o[i] );
			image_filter_brightness(parseInt(o.filters), false);
			break;
		};
	}; 	
};
function run_redo(){
	db.transaction(function(d){
	if (redo_id == undefined)
		redo_id = undo_id;
	else{
		db.transaction(function(tx){
				tx.executeSql('select * from history where painter_id="'+painter_id+'" and id>='+redo_id+' and step_id=0 order by id asc limit 1 ; ', [], function(tx, results){
					if(results.rows.length>0){
						var o = results.rows.item(0);
						
						redo_id = o.id;
					}
				});
			});
	}
	//var sql = 'select * from history where painter_id="'+painter_id+'" and id="'+id+'"; ';
	if(redo_id > undo_id){
		redo_id = undo_id;
		var sql = 'select * from history where painter_id="'+painter_id+'" and id<='+redo_id+' and step_id=0 order by id asc limit 1 ; ';
	}else{
		var sql = 'select * from history where painter_id="'+painter_id+'" and id>='+redo_id+' and step_id=0 order by id asc limit 1 ; ';
	}
	console.log(sql);
	d.executeSql(sql, [], function(tx, results){
		if(results.rows.length>0){
			var o = results.rows.item(0);
			if(o.action_function == 'moving')
				redo_move(o);
			if(o.action_function == 'scaling')
				redo_scale(o);
			if(o.action_function == 'rotating')
				redo_rotate(o);
			if(o.action_function == 'object_behind')
				redo_object_behind(o);
			if(o.action_function == 'bring_forward')
				redo_bring_forward(o);
			if(o.action_function == 'delete object')
				delete_object();
            if(o.action_function == 'enlarge object')
                redo_enlarge_object(o);
            if(o.action_function == 'decrease object')
                redo_decrease_object(o);
			if(o.action_function == 'image_filter_opacity')
                redo_image_filter_opacity(o);
			if(o.action_function == 'image_filter_brightness')
                redo_image_filter_brightness(o);
			
			db.transaction(function(tx){
					//if(redo_id > undo_id)
					//	redo_id = undo_id;
					tx.executeSql('update history set step_id=1 where painter_id="'+painter_id+'" and id = '+redo_id+' ; ', [], function(tx, results){
				});
			});
		}
	});
	});
};

/*
function direct_move(id){
	db.transaction(function(d){
	var sql = 'select * from history where painter_id="'+painter_id+'" and id="'+id+'"; ';
	d.executeSql(sql, [], function(tx, results){
		if(results.rows.length>0){
			var o = results.rows.item(0);
			var next_o = canvas.getActiveObject();
			next_o.set({top:o.top, left:o.left});
			next_o.adjustPosition();
			canvas.renderAll();
		}
	});
	});
};
*/
function get_undo_result(data){
	if(data.id != undefined){
		db.transaction(function(d){
			undo_id = (data.id)-1;
			//console.log('undo_id = ' + undo_id);
			d.executeSql('select * from history where painter_id="'+painter_id+'" and id="'+undo_id+'"; ', [], function(tx, results){
				if(results.rows.length > 0){
					var o = results.rows.item(0);
					if(o.action_function == 'moving')
						undo_move(o);
				}
			});
		});
	}
};

function get_redo_result(data){
	if(data.id != undefined){
		db.transaction(function(d){
			redo_id = (data.id)+1;
			//console.log('redo_id = ' + redo_id);
			d.executeSql('select * from history where painter_id="'+painter_id+'" and id="'+redo_id+'"; ', [], function(tx, results){
				if(results.rows.length > 0){
					var o = results.rows.item(0);
					if(o.action_function == 'moving')
						redo_move(o);
				}
			});
		});
	}
};

function adjust_layer() {
    canvas.bringToFront(middle_line);
};
$.fn.insertAt = function(elements, index) {
    var children = this.children().clone(true);
    var array = $.makeArray(children);
    array.splice(index, 0, elements);
    this.empty().append(array);
    return this;
};
function add_layer(index){
	var o = canvas.getActiveObject();
	var img;
	var name = '物件';
	if (o.type == 'image'){
		img = '<img id="img_'+o.id+'" src="'+o._originalImage.attributes.src.value+'" width="50">';
		
        if(o.filename == undefined){
            var filename = o._originalImage.attributes.src.value.split('/');
            filename = filename[filename.length-1];
            name = filename;
        }else{
			var filename = o._originalImage.attributes.src.value.split('/');
            filename = filename[filename.length-1];
            if(filename.length > 100)
                name = 'Masked';
            else
            name = filename;
        }
	}
	if (o.type == 'text'){
		img = '<img id="img_'+o.id+'" src="painter/images/text.png" width="50">';
		name = o.text;
	}
		
	
	
	var new_layer = '<div id="layer_id_'+o.id+'" class="layer_block">'+
				img+
				'<span id="layer_name_'+o.id+'">'+name+'</span>'+
				'</div>';
	//console.log(new_layer);
	if(index == undefined)
		$("#layer_list").prepend(new_layer);
	else
		$("#layer_list").insertAt(new_layer, index);

	$("#img_"+o.id).bind('contextmenu', function(evt){
		layer_div = $("#layer_id_"+o.id);
        active_object_from_id(o.id);
		show_layer_right_menu(layer_div.offset().left,evt.pageY);
		return false;
	});
    $("#layer_name_"+o.id).bind('contextmenu', function(evt){
		layer_div = $("#layer_id_"+o.id);
        active_object_from_id(o.id);
		show_layer_right_menu(layer_div.offset().left,evt.pageY);
		return false;
	});
	
};

function close_finish_dialog(){
    finish_dialog.dialog('close');
};


function completed(){
	save();
	if (order_detail_id == undefined){
		alert('尚未編輯任何工作，請於[作品清單]上選擇預進行編輯的工作。');
		return false;
	}
    finish_dialog = $("#finish_dialog");
	finish_dialog.dialog({width: 350}).css({'font-size':'12px'});
	/*
	if (confirm('[完成製作]: 是否需美工人員預覽作品並提供建議? \n\n 完成製作後使用者只能預覽，不能修改作品。')){
		$.get('HandlerPainter.ashx?action=finish_painter',{'order_detail_id':order_detail_id,'painter_id': painter_id},function(data){
	
		});
	}
	*/
	
};

function continue_edit(){
    checkout_dialog.dialog('close');
    get_work_list();
};

function close_work_list(){
	$("#work_list").fadeOut();  
};
function open_work_list(){
    $("#work_list").fadeIn();
};

function get_work_list(){
	var c = url.parse(location.search);
	var ref = c.get.ref;
    total_work_list = 0;
    not_yet_finish_work_list = 0;
	var json = {};
	json.order_id = order_id;
	var json = jQuery.parseJSON(JSON.stringify(json));
	$.ajax({
		dataType: "json",
		url: 'HandlerPainter.ashx?action=get_work_list',
		data: json,
		success: function (data) {
			if (data.id == '000'){
				$("#work_list").html("");
				var wl = JSON.parse(data.message);
					$("#work_list").append("<div align='center' style='background-color:blue;color:#ffffff;'> 請從底下清單裡選擇進行編輯的項目 </div>");
                ////console.log(wl.work_list.length);
                if(wl.work_list.length == 0){
                    alert('您沒有任何一筆作品清單，請回首頁重新選擇商品。');
                    //window.location.href='/';
                    return false;
                };
				$.each(wl.work_list, function(k, v){
                    total_work_list++;
					////console.log(v.painter_status);
                    t = '(未編輯)';
					current_work_name = v.product_type+': '+v.product_spec.replace('<br>',' ')+' (W):'+v.width+' (H):'+v.height+' (張數): '+v.pages+'P ';
					
					if (v.painter_status == 'open'){
                        not_yet_finish_work_list++;
                        del_icon = '<img style="cursor:pointer" src="painter/images/icons/editdelete.png" onclick="delete_work_list(\''+v.order_detail_id+'\');">';
						cls = 'class="open_work_list" data-value="'+v.order_detail_id+'" onclick="exchange_painter(\''+v.painter_id+'\',\''+v.order_detail_id+'\',\''+v.width+'\',\''+v.height+'\',\''+v.pages+'\',\''+current_work_name+'\',\''+v.product_type+'\',\''+v.product_spec+'\',\''+v.confirm_order_detail_id+'\',\''+v.prod_id+'\',\''+v.bleed_width+'\',\''+v.bleed_height+'\');"';
					}else if (v.painter_status == 'finish'){
                        t = '(已完成-無法編輯與刪除)';
                        del_icon = '<img style="cursor:pointer" src="painter/images/icons/document-print-preview.png" onclick="preview_work(\''+v.order_detail_id+'\');">';
						cls = 'class="finish_work_list" ';
                    }else if (v.painter_status == 'edit'){
						t = '(編輯中)';
						not_yet_finish_work_list++;
						del_icon = '<img style="cursor:pointer" src="painter/images/icons/editdelete.png" onclick="delete_work_list(\''+v.order_detail_id+'\');">';
						cls = 'class="edit_work_list" data-value="'+v.order_detail_id+'" onclick="exchange_painter(\''+v.painter_id+'\',\''+v.order_detail_id+'\',\''+v.width+'\',\''+v.height+'\',\''+v.pages+'\',\''+current_work_name+'\',\''+v.product_type+'\',\''+v.product_spec+'\',\''+v.confirm_order_detail_id+'\',\''+v.prod_id+'\',\''+v.bleed_width+'\',\''+v.bleed_height+'\');"';
						
					}
					
					var work_list  = '<div>'+del_icon+' <label  '+cls+'>'+v.product_type+': '+v.product_spec+' (W):'+v.width+' (H):'+v.height+' (張數): '+v.pages+'P '+t+'</label></div>';
					$("#work_list").append(work_list);
				});
				$("#work_list").append('<label style="cursor:pointer;float:right" onclick="close_work_list()">[關閉]</a></label>');
				//$("#work_list").fadeIn();
                
                $("#show_work_amount").html(not_yet_finish_work_list+'/'+total_work_list);
				////console.log('first_coming'+first_coming);
				if (first_coming == true){
                    
					if(ref == undefined)
						$("#work_list > div:gt(0) > label[class='edit_work_list'], #work_list > div:gt(0) > label[class='open_work_list']").first().trigger('click');
					else if(ref == 'MemberCenter'){
						order_detail_id = c.get.order_detail_id;
						$("#work_list > div:gt(0) > label[data-value='"+order_detail_id+"']").trigger('click');
					}
                    //get_photos_page();
					first_coming = false;
				};
				
				
                get_material_filepath();
                get_preview_image();
                set_spec_data_painter();
				get_template();
				delete_history();
				
			}
			
		}
	}); 

};

function delete_history(){
db.transaction(function(tx){
	var sql = 'delete from history where painter_id="'+painter_id+'";';
		tx.executeSql(sql, [], function(tx, results){
		});
	});
};
function get_template(){
	$("#NewPage_Detail").html('');
	var p='<img src="/painter/images/empty_template.png" height="56" title="取消樣版" id="layout_1" style="cursor:pointer;" onclick="if(confirm(\'確定取消樣版?\')){read_template(\'del\');}">';
	
	$.getJSON('HandlerPainter.ashx?action=get_template',{'prod_id':prod_id, 'product_type':product_type,'product_spec':product_spec}, function(data){
		if(data){
			data = JSON.parse(data.message);
			$.each(data.file_list, function(k,v){
				p += '<img src="'+v.file_path+'" height="56" title="套用樣版" id="layout_1" style="cursor:pointer;" onclick="if(confirm(\'確定套用樣版?\')){read_template(\'local\','+k+');}">';
			});
		}
		//console.log(p);
		$("#NewPage_Detail").append(p);
	});
	
};

function close_preview_block(){
	$("#preview_block").hide();
};

function preview_work(id){
	canvas.discardActiveObject();
	canvas.renderAll();
	var _left = ((display_width/2)/2);
	var _top = ((display_height/2)/2);
	$("#preview_block").show();
	$("#preview_inner_box").css({'width':display_width+'px','height':display_height+'px','top':_top+'px','left':_left+'px'});
	var preview_image = document.getElementById("preview_image");
	preview_image.src = canvas.toDataURL('png');
	
	close_work_list();
};

function delete_work_list(id){
    if (confirm('確定刪除此工作嗎?')){
        $.getJSON('HandlerPainter.ashx?action=delete_work_list&order_detail_id='+id+'&painter_id='+painter_id,{}, function(data){
            if(data.id == '000'){
                close_work_list();
                get_work_list();
            }
        });
    };
    
    return false;
};

function exchange_painter(pid,id,width,height,pages,current_work_name, producttype, productname,confirmorderdetailid, p, bleed_width, bleed_height){
    //if (confirm('確定編輯此工作嗎?')){
	prod_id = p;
    real_height = width;
	real_width = height;
	real_bleed_height = bleed_width;
	real_bleed_width = bleed_height;
	
	clear_painter();
    
    //prevent get painter id again.
    if(pid == 'undefined' || pid == '' || pid == 'null'){
        get_painter_id();
    }else{
        painter_id = pid;
    }
        
	order_detail_id = id;
	product_type = producttype;
	product_spec = productname;
	confirm_order_detail_id = confirmorderdetailid;
	
    painter_width = (parseInt(width)*37.79) * 0.5;
    painter_height = (parseInt(height)*37.79) * 0.5;
    painter_pages = parseInt(pages);
    
    create_pages_for_painter();
    close_init_box();
    /*
    canvas.setWidth(painter_width);
    canvas.setHeight(painter_height);
    $("#mycanvas_base").css({'width':painter_width,'height':painter_height});
    $("#separate_line").css({'width':painter_width/2,'height':painter_height});
    */
    //get_work_list();
	close_work_list();
	spec = '<select id="spec" name="spec" onchange="set_spec_data();">'+
		   '<option value="'+current_work_name+'" data-width="'+real_width+'" data-height="'+real_height+'" data-bleed-width="'+real_bleed_width+'" data-bleed-height="'+real_bleed_height+'" data-prodid="'+prod_id+'" selected>'+current_work_name+'</option>'+
		   '</select>';
	$("#current_work_name").html(current_work_name + spec);
    read_before_save_data();
    get_photos_page();
    //};
    return false;
};

function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
};

function clear_painter(){	
    canvas.setBackgroundImage('', function () { canvas.renderAll(); });
	for(var i=1; i<=total_objects;i++){
		canvas._objects.pop();
		sleep(100);
		//console.log('clear '+i);
	}
	canvas.renderAll();
	$("#layer_list").html('');
	total_objects = 0;
    background_image = undefined;
};

function put_template_objects_on_painter(o){
	fabric.Image.fromURL(o.filename, function (oImg) {
		//var zc = o.zoomout_count;
		//if (parseFloat(zc) <= 0.0)
		zc = 1;
		oImg.set('id',o.object_index);
		//oImg.set('width',o.width * parseFloat(zc) );
		//oImg.set('height', o.height  * parseFloat(zc) );
		oImg.set('originY','top');
		oImg.set('originX','left');
		oImg.set('width',o.width / o.scaleX );
		oImg.set('height', o.height  / o.scaleY );
		oImg.set('left', o.left  * parseFloat(zc) );
		oImg.set('top', o.top  * parseFloat(zc) );
		oImg.set('selectable', o.selectable);
		oImg.set('opacity', o.opacity);
		oImg.set('scaleX', o.scaleX);
		oImg.set('scaleY', o.scaleY);
		oImg.set('angle', o.angle);
		oImg.set('filename', o.filename);
		oImg.set('isdelete', o.isdelete);
		oImg.set('istemplate', true);
		oImg.set('use_filters', o.filters_type);
		oImg.set('use_filters_val', o.filters_val);
		oImg.set('selectable', false);
		canvas.insertAt(oImg, parseInt(o.layer_index));
		canvas.renderAll();
		canvas.setActiveObject(oImg);

	});	
};
function put_objects_on_painter(o){
    if(o.type == "image"){
        fabric.Image.fromURL(o.filename, function (oImg) {
			if (location.pathname == '/painter_template.html' || location.pathname == '/doitwell02/painter_template.html' ){
				//var zc = o.zoomout_count;
				//if (parseFloat(zc) <= 0.0)
					zc = 1;
				oImg.set('id',o.object_index);
				//oImg.set('width',o.width * parseFloat(zc) );
				//oImg.set('height', o.height  * parseFloat(zc) );
				oImg.set('originY','top');
				oImg.set('originX','left');
				oImg.set('width',o.width / o.scaleX );
				oImg.set('height', o.height  / o.scaleY );
				oImg.set('left', o.left  * parseFloat(zc) );
				oImg.set('top', o.top  * parseFloat(zc) );
				oImg.set('selectable', o.selectable);
				oImg.set('opacity', o.opacity);
				oImg.set('scaleX', o.scaleX);
				oImg.set('scaleY', o.scaleY);
				oImg.set('angle', o.angle);
				oImg.set('filename', o.filename);
				oImg.set('isdelete', o.isdelete);
				oImg.set('use_filters', o.filters_type);
				oImg.set('use_filters_val', o.filters_val);
            }else{
				oImg.set('id',o.object_index);
				oImg.set('originY','top');
				oImg.set('originX','left');
				oImg.set('width',o.width);
				oImg.set('height', o.height);
				oImg.set('left', o.left);
				oImg.set('top', o.top);
				oImg.set('selectable', o.selectable);
				oImg.set('opacity', o.opacity);
				oImg.set('scaleX', o.scaleX);
				oImg.set('scaleY', o.scaleY);
				oImg.set('angle', o.angle);
				oImg.set('filename', o.filename);
				oImg.set('isdelete', o.isdelete);
				oImg.set('use_filters', o.filters_type);
				oImg.set('use_filters_val', o.filters_val);
				oImg.set('istemplate', o.istemplate);
				oImg.set('has_apply_template', o.has_apply_template);
				
				if(o.istemplate == 'true')
					oImg.set('selectable', false);
			
			}

			//console.log('o.filters_type = ' + o.filters_type);
			if(o.before_mask_image != undefined && o.before_mask_image != "undefined")
				oImg.set('before_mask_image', o.before_mask_image);
            
            if (o.filters_type == 'Brightness'){
                oImg.filters.push(new fabric.Image.filters.Brightness({ brightness: parseInt(o.filters_val) }));
                oImg.applyFilters(canvas.renderAll.bind(canvas));
            };
            if (o.filters_type == 'Sepia'){
            	oImg.filters.push(new fabric.Image.filters.Sepia2());
				oImg.applyFilters(canvas.renderAll.bind(canvas));
            };
            if (o.filters_type == 'Blur'){
            	for(var i = 0; i < 10; i++){
	            oImg.filters.push(new fabric.Image.filters.Convolute({
					matrix: [ 1/9, 1/9, 1/9,
							  1/9, 1/9, 1/9,
							  1/9, 1/9, 1/9 ]
				}));
				};
				oImg.applyFilters(canvas.renderAll.bind(canvas));
			};
			if (o.filters_type == 'Sharpen'){
				oImg.filters.push(new fabric.Image.filters.Convolute({
					matrix: [ 0, -1,  0,
							  -1,  5, -1,
							   0, -1,  0 
							  ]
				}));
				oImg.applyFilters(canvas.renderAll.bind(canvas));				
			};
			if (o.filters_type == 'Opacity'){
				oImg.set({opacity:o.filters_val});
				canvas.renderAll();
			};
			
			if (o.filters_type == 'Emboss'){
				oImg.filters.push(new fabric.Image.filters.Convolute({
					matrix: [ 1,   1,  1,
							  1, 0.7, -1,
							 -1,  -1, -1
							  ]
				}));
				oImg.applyFilters(canvas.renderAll.bind(canvas));
			};
            canvas.insertAt(oImg, parseInt(o.layer_index));
            canvas.renderAll();
            canvas.setActiveObject(oImg);
			
			if(o.istemplate == 'false')
            add_layer(parseInt(o.layer_index));
        });	
        total_objects++;
    }
    if(o.type == "text"){
    	_fontStyle = 'normal';
    	if (o.fontStyle != 'undefined')
    		_fontStyle = o.fontStyle;
        var new_text = new fabric.Text(o.fontText, {
		id: o.object_index,
        fontFamily: o.fontFamily,
        fontSize: parseInt(o.fontSize),
        fontStyle: _fontStyle,
        strokeWidth: parseInt(o.strokeWidth),
        stroke: o.stroke,
        fill: o.fill,
        left: o.left,
        top: o.top,
        width: o.width,
        height: o.height,
        scaleX: o.scaleX,
        scaleY: o.scaleY,
        angle: o.angle,
		textShadow: o.textShadow,
		fontWeight: o.fontWeight,
		textDecoration: o.textDecoration,
		output_pass: false,
		always_on_top: false,
        isdelete: o.isdelete
        });
        canvas.insertAt(new_text, parseInt(o.layer_index));
        canvas.renderAll();
        canvas.setActiveObject(new_text);
        
        add_layer(parseInt(o.layer_index));
        total_objects++;
    }
    
    if (o.background_image != 'undefined' && o.background_image != undefined)
        canvas.setBackgroundImage(o.background_image, function () { canvas.renderAll(); });
    
	if (o.template_image != 'undefined' && o.template_image != undefined)
		set_template(o.template_image)
		
    //console.log('background_image = ' + o.background_image);
    background_image = o.background_image;
};



function read_before_save_data(){
	db.transaction(function(d){
        //console.log('select * from painter_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;');
		d.executeSql('select * from painter_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;', [], function(tx, results){
			if(results.rows.length > 0){
				//var o = results.rows.item(0);
				for (i = 0; i < results.rows.length; i++){				
					//z(results.rows.item(i));
					put_objects_on_painter(results.rows.item(i));
					setTimeout(function (){
					},3000);
				};
				$("#fontSelect").trigger('click');$("ul[class=fontSelectUl]").hide();
				canvas.renderAll();	
			}
		});
	});
};
/*
function read_before_template_save_data(){
	db.transaction(function(d){
        console.log('select * from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;');
		d.executeSql('select * from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;', [], function(tx, results){
			if(results.rows.length > 0){
				for (i = 0; i < results.rows.length; i++){				
					put_objects_on_painter(results.rows.item(i));
					setTimeout(function (){
						console.log('delay');
					},3000);
				};
				canvas.renderAll();	
			}
		});
	});
};
*/
function exchange_pages(p){
	page_id = p;
	clear_painter();
	read_before_save_data();        
	$("#page_number").html('['+(page_id+1)+']');
	set_template(apply_template_record[page_id]);
	/*
    //if (confirm('確定切換頁面 '+(p+1)+' 嗎?')){
        page_id = p;
		clear_painter();
		read_before_save_data();        
        //alert(p);
        $("#page_number").html('['+(page_id+1)+']');
    //}
	*/
};

function exchange_template_pages(p){
        page_id = p;
		set_spec_data();
		//clear_painter();
		//read_before_template_save_data();        
        $("#page_number").html('['+(page_id+1)+']');
};

function create_pages_for_painter(){
	$("#pages_list").html('');
    for(var i = 0; i < painter_pages; i++){
        var p = '<div id="pageid_'+i+'">'+
            '<table>'+
            '<tr><td><img onclick="exchange_pages('+i+')" style="cursor:pointer;background-color:#ffffff;" src="painter/images/page.png" width="90" border="1"></td></tr>'+
            '<tr><td align="center">['+(i+1)+']</td></tr>'+
            '</table>'+
            '</div>';
        $("#pages_list").append(p);
    };
    
};

function apply_mask(maskImg,maskWidth, maskHeight){
	o = canvas.getActiveObject();
	des_id = o.id;
	des_width = o.currentWidth;
	des_height = o.currentHeight;
	des_left = o.left;
	des_top = o.top;
	source_image = o.getSrc();	
	
	
	$("#temp_div").html('');
	$("#temp_div").append('<canvas id="temp_canvas" width="'+des_width+'" height="'+des_height+'"></canvas>');
	$("#temp_canvas").css({'width': (des_width)+'px','height':(des_height)+'px'});
	
	var temp_canvas = document.getElementById('temp_canvas');
    var context = temp_canvas.getContext('2d');
	var imageObj =  document.createElement('img');
	imageObj.src = source_image;
	
	
	
	var img = document.createElement('img');
	img.src = maskImg;
	context.drawImage(imageObj, 0, 0,des_width,des_height);
	context.globalCompositeOperation = 'destination-atop';
	//mask fiting to destination image.
	context.drawImage(img, 0, 0, des_width, des_height);
	$("#layer_list").find("div[id='layer_id_"+o.id+"']").hide();
	o.remove();
	
	var new_mask_img = new Image();
	new_mask_img.src = temp_canvas.toDataURL();
	
	fabric.Image.fromURL(new_mask_img.src, function (oImg) {
	oImg.set('id',des_id);
	oImg.set('filename',new_mask_img.src);
	oImg.set('isdelete','N');
	oImg.set('width',des_width);
	oImg.set('height', des_height);
	oImg.set('left', des_left);
	oImg.set('top', des_top);
	oImg.set('before_mask_image', source_image);       
	oImg.set('originX', 'left');
	oImg.set('originY', 'top');
	oImg.set('istemplate', false);
	oImg.set('has_apply_template', false);
	canvas.add(oImg);
	canvas.renderAll();
	canvas.setActiveObject(oImg);
	add_layer();
	record_step('遮罩');
	});    	
	
};

function undo_mask(){
	o = canvas.getActiveObject();
	if(o.before_mask_image != undefined && o.before_mask_image != "undefined"){
		var my_left = o.left;
		var my_top = o.top;
		var my_width = o.width;
		var my_height = o.height;
		var my_id = o.id;
		var my_filename = o.before_mask_image;
		o.remove();
		
		fabric.Image.fromURL(my_filename, function (oImg) {
        oImg.set('id',my_id);
        oImg.set('filename',my_filename);
        oImg.set('isdelete','N');
        oImg.set('width',my_width);
        oImg.set('height', my_height);
        oImg.set('left', my_left);
        oImg.set('top', my_top);
		oImg.set('originX', 'left');
		oImg.set('originY', 'top');
		oImg.set('istemplate', false);
		oImg.set('has_apply_template', false);
        canvas.add(oImg);
        canvas.renderAll();
        canvas.setActiveObject(oImg);
		});
		close_right_menu();
	};
};

function open_mask_block(maskImg, maskWidth, maskHeight){
	init();
	draw();
	var maskCanvas = document.getElementById('maskCanvas');
    var context = maskCanvas.getContext('2d');
	var source_image;
	var re_des_width;
	var re_des_height;
	var x=10;
	var y=10;
	var mousedown = false;
    var apply = false;
    var des_width;
	var des_height;
    var des_left;
    var des_top;
    var des_id;
    
	open_mask_block.move = move;
	open_mask_block.mask_zoomOut = mask_zoomOut;
	open_mask_block.mask_zoomIn = mask_zoomIn;
	open_mask_block.mask_fit = mask_fit;
	open_mask_block.mask_apply = mask_apply;
	open_mask_block.mask_undo_apply = mask_undo_apply;
	open_mask_block.mask_output = mask_output;
	
    
    function mask_output(){
        //console.log(maskCanvas.toDataURL());
        o = canvas.getActiveObject();
		$("#layer_list").find("div[id='layer_id_"+o.id+"']").hide();
		o.remove();
		
        var new_mask_img = new Image();
        new_mask_img.src = maskCanvas.toDataURL();
        
        fabric.Image.fromURL(new_mask_img.src, function (oImg) {
        oImg.set('id',des_id);
        oImg.set('filename',new_mask_img.src);
        oImg.set('isdelete','N');
        oImg.set('width',des_width);
        oImg.set('height', des_height);
        oImg.set('left', des_left);
        oImg.set('top', des_top);
		oImg.set('originX', 'left');
		oImg.set('originY', 'top');
        oImg.set('before_mask_image', source_image);
		oImg.set('istemplate', false);
		oImg.set('has_apply_template', false);
/*
        oImg.set('selectable', o.selectable);
        oImg.set('opacity', o.opacity);
        oImg.set('scaleX', o.scaleX);
        oImg.set('scaleY', o.scaleY);
        oImg.set('angle', o.angle);
        oImg.set('filename', o.filename);
        oImg.set('isdelete', o.isdelete);
*/            
        canvas.add(oImg);
        canvas.renderAll();
        canvas.setActiveObject(oImg);
            
        add_layer();
        close_mask_block();
		record_step('遮罩');
        });    
    };
    
    function mask_fit(){
		x=0;
		y=0;
        maskWidth = re_des_width;
        maskHeight = re_des_height;
		context.clearRect(x,y,maskWidth,maskHeight);
        draw();
    };
    function mask_undo_apply(){
        apply = false;
        draw();
    };
    function mask_apply(){
        apply = true;
        draw();
    };
    
	function mask_zoomIn(){
        maskWidth *= 1.5;
        maskHeight *= 1.5;
		
        draw();
	};
	function mask_zoomOut(){
        maskWidth /= 1.5;
        maskHeight /= 1.5;
        draw();
	};
	
	function init(){
		//console.log('call init...');
		var o = canvas.getActiveObject();
		des_width = o.currentWidth;
		des_height = o.currentHeight;
        des_left = o.left;
        des_top = o.top;
        des_id = o.id;
		//o.before_mask_image = o.getSrc();
		//o.saveState();
		source_image = o.getSrc();
		var rate = 330 / des_height;
		re_des_width = des_width * rate;
		re_des_height = des_height * rate;
		$("#mask_block").html('');
		$("#mask_block").append('<label style="cursor:pointer;float:right" onclick="close_mask_block()">[關閉]</a></label>');
		//$("#mask_block").append('<input type="radio" name="op" value="destination-out" checked="checked" />留下底圖');
		//$("#mask_block").append('<input type="radio" name="op" value="destination-atop" />底圖置入<br/>');
		$("#mask_block").append('<button type="button" onclick="open_mask_block.mask_fit()">填滿</button>');
		$("#mask_block").append('<img src="painter/images/icons/stock_zoom-out.png" onclick="open_mask_block.mask_zoomOut()">');
		$("#mask_block").append('<img src="painter/images/icons/stock_zoom-in.png" onclick="open_mask_block.mask_zoomIn()">');
		$("#mask_block").append('<button type="button" onclick="open_mask_block.mask_undo_apply()">復原套用</button>');
		$("#mask_block").append('<button type="button" onclick="open_mask_block.mask_apply()">套用</button>');
		$("#mask_block").append('<button type="button" onclick="open_mask_block.mask_output()">確定套用</button>');
		$("#mask_block").append('<label style="font-size:11px;">(注意:套用遮罩後將無法還原至原圖)。</label><br/>');
		$("#mask_block").append('<canvas id="maskCanvas" width="'+re_des_width+'" height="'+re_des_height+'"></canvas>');
		$("#mask_block").css({'width': (re_des_width+30)+'px','height':(re_des_height+70)+'px'});
	};
	
	function draw(){
		var imageObj =  document.createElement('img');
		imageObj.src = source_image;
		var img = document.createElement('img');
		img.src = maskImg;
		imageObj.onload = function() {
		context.drawImage(imageObj, 0, 0,re_des_width,re_des_height);

		//context.scale(rate,rate); //bug!!
        if(apply == true){
			context.globalAlpha = 1.0;
            //context.globalCompositeOperation = $("input[name=op]:checked").val();
            context.globalCompositeOperation = 'destination-atop';
        }else{
			context.globalAlpha = 0.5;
            context.globalCompositeOperation = 'source-over';
		};
        
		context.drawImage(img, x, y, maskWidth, maskHeight);
		//context.fillStyle = 'rgba(255,255,255,0.0)';
		//context.fillRect(x,y,maskWidth,maskHeight);
		
		/*
        var ipic = context.getImageData(x, y, maskWidth, maskHeight);
		var idata = ipic.data;
		for (var i = 0; i < idata.length; i += 4) 
		{
		idata[i+3] = 128;
		}
		context.putImageData(ipic, x, y);
		*/
		
		};
		
	};
	function move(){
		//console.log('x = ' + x + 'y = ' +y+ 'maskWidth = ' +maskWidth+ 'maskHeight = ' + maskHeight);
        context.clearRect(x,y,maskWidth,maskHeight);
        x = x+20;
        draw();
    }

	function getMousePos(maskCanvas, evt) {
		var rect = maskCanvas.getBoundingClientRect();
		return {
			x: evt.clientX - rect.left,
			y: evt.clientY - rect.top
		};
	}
	maskCanvas.addEventListener('mousemove', function(evt) {
		if(mousedown){
			var mousePos = getMousePos(maskCanvas, evt);
				x = mousePos.x-(maskWidth/2);
				y = mousePos.y-(maskHeight/2);
                
                if(apply == false){
                    draw();
                    context.clearRect(x,y,maskWidth,maskHeight);
                };
				//console.log('x = ' + x + 'y = ' +y+ 'maskWidth = ' +maskWidth+ 'maskHeight = ' + maskHeight);
		};
	}, false);    
    maskCanvas.addEventListener('mousedown', function(evt) {
		mousedown = true;
	}, false);    
    maskCanvas.addEventListener('mouseup', function(evt) {
		mousedown = false;
	}, false);    

    $("#mask_block").fadeIn();
};

function close_reference(){
	$("#reference_block").fadeOut();
};

function open_reference(){
	$("#reference_block").html('<img src="painter/images/reference_photo.jpg">');
	$("#reference_block").append('<label style="cursor:pointer;float:right" onclick="close_reference()">[關閉]</a></label>');
	$("#reference_block").fadeIn();
};

function open_image_filters(){
    isnewobject = false;
	isnewfont = false;
	isdelete = false;
    isenlarge_object = false;
    isdecrease_object = false;
	ismoving = false;
	isscaling = false;
	isrotating = false;
    
	$("#image_filters_block").fadeIn();
    close_work_list();
	
};

function close_image_filters(){
	$("#image_filters_block").fadeOut();
};

var template_mask = document.createElement('img');
var template_mask_last = new Image();
function process_template(v, l, t, currentWidth, currentHeight){
	var rectangle = new fabric.Rect({
		left:0,
		top: 0,
		fill: '#ffffff',
		width: display_width,
		height: display_height,
		opacity: 0.70,
	});
	template_mask.width = display_width;
	template_mask.height = display_height;
	des_width = display_width;
	des_height = display_height;
	source_image = v.getSrc();         
	var temp_div = document.createElement('canvas');
	temp_div.width = display_width;
	temp_div.height = display_height;
	var context = temp_div.getContext('2d');
	//var template_mask =  document.createElement('img');
	if(template_mask.src == ""){
		template_mask.src = rectangle.toDataURL();
	}else{
		template_mask.src = template_mask_last.src;
	}
	
	

	var img = document.createElement('img');
	//img.src = v.toDataURL();
	img.src = v.getSrc();
	img.height = currentHeight;
	img.width = currentWidth;
	
	//console.log(img.src);
	context.drawImage(template_mask, 0, 0,des_width,des_height);
	//context.globalCompositeOperation = 'destination-out';
	
	//mask fiting to destination image.
	context.drawImage(img, l, t, currentWidth, currentHeight);
	//var new_mask_img = new Image();
	//new_mask_img.src = temp_div.toDataURL();
	template_mask_last.src = temp_div.toDataURL();
	//console.log('=============template_mask_last.src============');
	//console.log(template_mask_last.src);
};

function template_save(){
	db.transaction(function(d){
		d.executeSql('create table IF NOT EXISTS painter_template_save (id INTEGER PRIMARY KEY AUTOINCREMENT,order_detail_id text, painter_id integer,page_id integer, user_name text,layer_index integer, object_index integer, type text,top real,left real,width real,height real,selectable text,opacity real,scaleX real,scaleY real,fill text,radius real,angle real,stroke text,strokeWidth real,strokeDashArray text,filename text,action_function text,step_name text, isdelete text,filters_type text, filters_val text, background_image text, fontSize text, fontFamily text, fontText text, before_mask_image text, fontStyle text, textShadow text, fontWeight text, textDecoration text, zoomout_count real);');
	});
	
	db.transaction(function(d){
		d.executeSql('delete from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'"');
		//console.log('delete from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'"');
	});

	var json = {};
	var objects = canvas._objects;
	
	json.painter = painter_id;
	json.page_id = page_id;
	json.order_id = order_id;
	json.order_detail_id = order_detail_id;
    json.background_image = background_image;
	json.properties = [];
	template_mask.removeAttribute('src');
	$.each(objects, function(k, v){
		if(k>0){
			if(v.isdelete == 'N'){
				var d = {};
				json.properties.push(d);
				d.painter_id = painter_id;
				d.user_name =  session_name;
				d.layer_index = k;
				d.object_index = v.id;
				d.type = v.type;
				
				if(zoomout_count > 1){
					d.top = v.top / zoomout_count;
					d.left = v.left / zoomout_count;
					d.width = v.currentWidth / zoomout_count;
					d.height = v.currentHeight / zoomout_count;
					process_template(v, d.left, d.top, d.width, d.height);
				}
				if(zoomout_count < 1){
					//console.log('d.top = ' + v.top);
					//console.log('d.left = ' + v.left);
					//console.log('zoomout_count = ' + zoomout_count);
					
					d.top = v.top;
					d.left = v.left;
					d.width = v.currentWidth / zoomout_count;
					d.height = v.currentHeight / zoomout_count;
					process_template(v, (v.left), (v.top), d.width, d.height);
					//console.log('d.top = ' + v.top);
					//console.log('d.left = ' + v.left);
					
					//process_template(v, (v.left/v.scaleX)*zoomout_count, (v.top/v.scaleX)*zoomout_count, d.width, d.height);
				}
				if(zoomout_count == 1){
					d.top = v.top;
					d.left = v.left;
					d.width = v.currentWidth;
					d.height = v.currentHeight;
					//process_template(v, v.left-(30), v.top-(30), d.width, d.height);
					//process_template(v, (v.left/v.scaleX), (v.top/v.scaleY), d.width, d.height);
					process_template(v, (v.left), (v.top), d.width, d.height);
				}
				d.order_detail_id = order_detail_id;
				d.page_id = page_id;
				d.selectable = v.selectable;
				d.opacity = v.opacity;
				d.scaleX = v.scaleX;
				d.scaleY = v.scaleY;
				d.fill = v.fill;
				d.radius = v.radius;
				d.angle = v.angle;
				d.stroke = v.stroke;
				d.strokeWidth = v.strokeWidth;
				d.strokeDashArray = v.strokeDashArray;
				d.filename = v.filename;
				d.action_function = '';
				d.step_name = '';
				d.isdelete = v.isdelete;
				d.filters_type = v.use_filters;
				d.filters_val = v.use_filters_val;
				d.fontSize = v.fontSize;
				d.fontFamily = v.fontFamily;
				d.fontText = v.text;
				d.fontStyle = v.fontStyle;
				d.fontWeight = v.fontWeight;
				d.textDecoration = v.textDecoration;
				d.textShadow = v.textShadow;
				d.before_mask_image = v.before_mask_image;
				json.properties.push();
				
				//console.log(d);
				
				$.ajax({
					type: 'POST',
					dataType: "json",
					url: 'HandlerPainter.ashx?action=template_save',
					data: JSON.stringify(d),
					success: function (data) {
						//console.log(data.mess);
                        if (data.id == '999')
                            alert(data.message);
                    }
				});
				
				var sql = 'insert into painter_template_save (order_detail_id, painter_id, page_id, user_name, layer_index, object_index, type, top, left, width, height, '+
				'selectable, opacity, scaleX, scaleY, fill, radius, angle, stroke, strokeWidth, strokeDashArray, filename, action_function, step_name,isdelete, filters_type, filters_val,background_image, fontSize, fontFamily, fontText,before_mask_image, fontStyle, textShadow, fontWeight, textDecoration, zoomout_count)'+
				' values ("'+order_detail_id+'","'+d.painter_id+'","'+page_id+'","'+d.user_name+'","'+d.layer_index+'","'+d.object_index+'","'+d.type+'","'+d.top+'","'+d.left+'","'+d.width+'","'+d.height+'", '+
				' "'+d.selectable+'","'+d.opacity+'", "'+d.scaleX+'", "'+d.scaleY+'", "'+d.fill+'", "'+d.radius+'", "'+d.angle+'", "'+d.stroke+'", '+
				' "'+d.strokeWidth+'", "'+d.strokeDashArray+'", "'+d.filename+'", "'+d.action_function+'", "'+d.step_name+'","N","'+d.filters_type+'","'+d.filters_val+'","'+background_image+'","'+d.fontSize+'","'+d.fontFamily+'","'+d.fontText+'","'+d.before_mask_image+'","'+d.fontStyle+'", "'+d.textShadow+'","'+d.fontWeight+'","'+d.textDecoration+'","'+zoomout_count+'" )';

				//console.log(sql);
				db.transaction(function(d){
					d.executeSql(sql);
				});
			};
		};
	});	
    var d = new Date();
    var filename_for_this_save = painter_id+'_'+page_id+'_' + '.png';
    var json = {};
    json.type = 'template_preview';
    json.painter_id = painter_id;
	json.product_type = product_type;
	json.product_spec = product_spec.replace('<br>', ' ');
    json.page_id = page_id;
    json.user_id = session_id;
    json.user_name = session_name;
    json.filename = filename_for_this_save;
    //json.data = canvas.toDataURL('png');
	json.data = template_mask_last.src;
    //console.log(json);
    var json = jQuery.parseJSON(JSON.stringify(json));
    $.ajax({
        type: 'POST',
        dataType: "json",
        url: 'HandlerPainter.ashx?action=template_image',
        data: json,
        success: function (data) {
            if (data.id == '999')
                alert(data.message);
            else        	
        		get_template_preview_image();
        		//alert('存檔成功!');
        }
    });
	
	return false;
};

function save(){
//	canvas.discardActiveObject();
//	canvas.renderAll();
	
	db.transaction(function(d){
		d.executeSql('create table IF NOT EXISTS painter_save (id INTEGER PRIMARY KEY AUTOINCREMENT,order_detail_id text, painter_id integer,page_id integer, user_name text,layer_index integer, object_index integer, type text,top real,left real,width real,height real,selectable text,opacity real,scaleX real,scaleY real,fill text,radius real,angle real,stroke text,strokeWidth real,strokeDashArray text,filename text,action_function text,step_name text, isdelete text,filters_type text, filters_val text, background_image text, fontSize text, fontFamily text, fontText text, before_mask_image text, fontStyle text, textShadow text, fontWeight text, textDecoration text, template_image text, istemplate text, has_apply_template text);');
	});
	
	db.transaction(function(d){
		d.executeSql('delete from painter_save where painter_id="'+painter_id+'" and page_id="'+page_id+'"');
		//console.log('delete from painter_save where painter_id="'+painter_id+'" and page_id="'+page_id+'"');
	});
	
	var json = {};
	var objects = canvas._objects;
	
	json.painter = painter_id;
	json.page_id = page_id;
	json.order_id = order_id;
	json.order_detail_id = order_detail_id;
    json.background_image = background_image;
	json.properties = [];
	$.each(objects, function(k, v){
		if(k>0){
            if(v.isdelete == 'N'){
                var d = {};
                json.properties.push(d);
                d.painter_id = painter_id;
                d.user_name =  session_name;
                d.layer_index = k;
                d.object_index = v.id;
                d.type = v.type;
                d.top = v.top;
                d.left = v.left;
                d.width = v.width;
                d.height = v.height;
                d.selectable = v.selectable;
                d.opacity = v.opacity;
                d.scaleX = v.scaleX;
                d.scaleY = v.scaleY;
                d.fill = v.fill;
                d.radius = v.radius;
                d.angle = v.angle;
                d.stroke = v.stroke;
                d.strokeWidth = v.strokeWidth;
                d.strokeDashArray = v.strokeDashArray;
                d.filename = v.filename;
                d.action_function = '';
                d.step_name = '';
                d.isdelete = v.isdelete;
                d.filters_type = v.use_filters;
                d.filters_val = v.use_filters_val;
                d.fontSize = v.fontSize;
                d.fontFamily = v.fontFamily;
                d.fontText = v.text;
				d.fontStyle = v.fontStyle;
				d.fontWeight = v.fontWeight;
				d.textDecoration = v.textDecoration;
				d.template_image = apply_template_record[page_id];
				d.textShadow = v.textShadow;
                d.before_mask_image = v.before_mask_image;
				d.istemplate = v.istemplate;
				d.has_apply_template = v.has_apply_template;
                json.properties.push();
                
                //console.log(d);

				$.ajax({
					type: 'POST',
					dataType: "json",
					url: 'HandlerPainter.ashx?action=save',
					data: JSON.stringify(d),
					success: function (data) {
                        if (data.id == '999')
                            alert(data.message);
                    }
				});
                var sql = 'insert into painter_save (order_detail_id, painter_id, page_id, user_name, layer_index, object_index, type, top, left, width, height, '+
                'selectable, opacity, scaleX, scaleY, fill, radius, angle, stroke, strokeWidth, strokeDashArray, filename, action_function, step_name,isdelete, filters_type, filters_val,background_image, fontSize, fontFamily, fontText,before_mask_image, fontStyle, textShadow, fontWeight, textDecoration, template_image, istemplate, has_apply_template)'+
                ' values ("'+order_detail_id+'","'+d.painter_id+'","'+page_id+'","'+d.user_name+'","'+d.layer_index+'","'+d.object_index+'","'+d.type+'","'+d.top+'","'+d.left+'","'+d.width+'","'+d.height+'", '+
                ' "'+d.selectable+'","'+d.opacity+'", "'+d.scaleX+'", "'+d.scaleY+'", "'+d.fill+'", "'+d.radius+'", "'+d.angle+'", "'+d.stroke+'", '+
                ' "'+d.strokeWidth+'", "'+d.strokeDashArray+'", "'+d.filename+'", "'+d.action_function+'", "'+d.step_name+'","N","'+d.filters_type+'","'+d.filters_val+'","'+background_image+'","'+d.fontSize+'","'+d.fontFamily+'","'+d.fontText+'","'+d.before_mask_image+'","'+d.fontStyle+'", "'+d.textShadow+'","'+d.fontWeight+'","'+d.textDecoration+'","'+d.template_image+'","'+d.istemplate+'","'+d.has_apply_template+'" )';

                //console.log(sql);
                db.transaction(function(d){
                    d.executeSql(sql);
                });
			};
		};
	});
    
    var d = new Date();
    var filename_for_this_save = order_id +'_'+ order_detail_id +'_'+ painter_id+'_'+page_id+'_' + '.png';
    var json = {};
    json.type = 'preview';
    json.order_detail_id = order_detail_id;
    json.painter_id = painter_id;
    json.page_id = page_id;
    json.user_id = session_id;
    json.user_name = session_name;
    json.filename = filename_for_this_save;
    json.data = canvas.toDataURL('png');
    var json = jQuery.parseJSON(JSON.stringify(json));
    $.ajax({
        type: 'POST',
        dataType: "json",
        url: 'HandlerPainter.ashx?action=upload_image',
        data: json,
        success: function (data) {
            //console.log(data);
        	if(data.id == '000')
        		get_preview_image(); //alert('存檔成功!');
            else        		
                alert(data.message);
        }
    });
    
	//console.log(json);
    
    return false;
	
};

function update_artist(){
	var json = {};
	json.painter_id = painter_id;
	if ($("#confirm_for_artist:checked").val() == "Y")
		json.artist = "Y";
	else
		json.artist = "N";
	var json = jQuery.parseJSON(JSON.stringify(json));
	$.ajax({
		dataType: "json",
		url: 'HandlerPainter.ashx?action=update_artist',
		data: json,
		success: function (data) {
			if (data.id == '000'){

                finish_dialog.dialog('close');
				
                checkout_dialog = $("#checkout_dialog");
                checkout_dialog.dialog({width: 350}).css({'font-size':'12px'});
				
				if(total_work_list == 1){
					$("#continue_edit_btn").hide();
					$("#continue_question").hide();
				}
            
			}else{                        
                alert(data.message);
            }
			
		}
	});

};
/*
o = canvas.getActiveObject();
o.clipTo = function(ctx){
//console.log(ctx);
//console.log(ctx.getImageData(0,0,50,50));
ctx.save();
ctx.beginPath();
ctx.rect(10, 10, 50, 50);
ctx.closePath();
ctx.restore();
}

//http://fabricjs.com/patterns/

http://christianheilmann.com/2013/06/15/image-masking-with-html5-canvas/
http://jsfiddle.net/AbdiasSoftware/4A4Qv/



*/

//loadPattern('file:///E:/painter/painter/albums/8.png');
/*
function loadPattern(url) {
  fabric.util.loadImage(url, function(img) {
	var o = canvas.getActiveObject();
	//o.fill = new fabric.Pattern({
    text.fill = new fabric.Pattern({
      source: img,
      repeat: 'no-repeat'
    });
    canvas.renderAll();
  });
};


var text = new fabric.Text('Honey,\nI\'m subtle', {
  fontSize: 250,
  left: 50,
  top: 200,
  lineHeight: 1,
  originX: 'left',
  fontFamily: 'Helvetica',
  fontWeight: 'bold'
});
canvas.add(text);
*/

/*
(function(){
  var imagecanvas = document.createElement('canvas');
  var imagecontext = imagecanvas.getContext('2d');

  window.addEventListener('load', function(){
    [].forEach.call(document.querySelectorAll('.mask'), function(img){
      var width  = img.offsetWidth;
      var height = img.offsetHeight;

      var mask = document.createElement('img');
      mask.src = img.getAttribute('data-mask');

      imagecanvas.width  = width;
      imagecanvas.height = height;

      imagecontext.drawImage(mask, 0, 0, width, height);
      imagecontext.globalCompositeOperation = 'source-atop';
      imagecontext.drawImage(img, 0, 0);

      img.src = imagecanvas.toDataURL();
    });
  }, false);

})();


<img src="red-panda.jpg" alt="Red panda" class="mask" data-mask="centerblur.png">
<img src="red-panda.jpg" alt="Red panda" class="mask" data-mask="star.png">

http://codepo8.github.io/canvas-masking/


REFERENCE: globalCompositeOperation  
https://developer.mozilla.org/samples/canvas-tutorial/6_1_canvas_composite.html
*/
/*
function clear_drop_function(){
	function handleDragStart(e) {
		[ ].forEach.call(images, function (img) {
			img.classList.remove('img_dragging');
		});
		this.classList.add('img_dragging');
	}

	function handleDragOver(e) {
		if (e.preventDefault) {
			e.preventDefault();
		}

		e.dataTransfer.dropEffect = 'copy';
		return false;
	}

	function handleDragEnter(e) {
		this.classList.add('over');
	}

	function handleDragLeave(e) {
		this.classList.remove('over');
	}

	function handleDrop(e) {

		if (e.stopPropagation) {
			e.stopPropagation();
		}
		return false;
	}

	function handleDragEnd(e) {
		[ ].forEach.call(images, function (img) {
			img.classList.remove('img_dragging');
		});
	}
    
if (Modernizr.draganddrop) {
    var images = document.querySelectorAll('.support_drag img');
    [ ].forEach.call(images, function (img) {
        img.removeEventListener('dragstart', handleDragStart, false);
        img.removeEventListener('dragend', handleDragEnd, false);
    });
    var canvasContainer = document.getElementById('mycanvas_base');
    canvasContainer.removeEventListener('dragenter', handleDragEnter, false);
    canvasContainer.removeEventListener('dragover', handleDragOver, false);
    canvasContainer.removeEventListener('dragleave', handleDragLeave, false);
    canvasContainer.removeEventListener('drop', handleDrop, false);
    } else {
    alert("This browser doesn't support the HTML5 Drag and Drop API.");
};

};
*/

function handleDragStart(e) {
	if (location.pathname == '/painter_template.html' || location.pathname == '/doitwell02/painter_template.html'){
		if(prod_id == undefined){
			alert('請選擇樣板');
			return false;
		}
			
	};
	if (location.pathname == '/painter.html' || location.pathname == '/doitwell02/painter.html'){
		if (order_detail_id == undefined){
			alert('請選擇要進行編輯的工作!');
			open_work_list();
			return false;
		};
	};
    [ ].forEach.call(drag_images, function (img) {
        img.classList.remove('img_dragging');
    });
    this.classList.add('img_dragging');
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }

    e.dataTransfer.dropEffect = 'copy';
    return false;
}

function handleDragEnter(e) {
    this.classList.add('over');
}

function handleDragLeave(e) {
    this.classList.remove('over');
}

function handleDrop(e) {
	var date = new Date();
	var apply_template = false;
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    var img = document.querySelector('.support_drag img.img_dragging');
    //console.log('x=' + e.offsetX + ' y=' + e.offsetY);
	o = canvas._objects;
	$.each(o, function(k,v){
		if(v.istemplate == true){
			/*
				offsetX=345 offsetY=24 painter.js:3121
				left=320 top=4currentWidth=60currentWidth=60 
			*/
			if( (e.offsetX > v.left && e.offsetY > v.top) && (e.offsetX < v.left+v.currentWidth && e.offsetY < v.top+v.currentHeight) ){
				apply_template = true;
				//console.log('touch template');
				var after_apply_template = sendto_template(img.src, v);
				
				var after_apply_template_image =  document.createElement('img');
				after_apply_template_image.src = after_apply_template.toDataURL();
				
				fabric.Image.fromURL(after_apply_template_image.src, function (oImg) {
					oImg.set('id',date.getTime());
					oImg.set('originY','top');
					oImg.set('originX','left');
					oImg.set('width',v.width);
					oImg.set('height', v.height);
					oImg.set('left', v.left);
					oImg.set('top', v.top);
					oImg.set('scaleX', v.scaleX);
					oImg.set('scaleY', v.scaleY);
					oImg.set('angle', v.angle);
					oImg.set('filename', after_apply_template_image.src);
					oImg.set('isdelete', 'N');
					oImg.set('istemplate', true);
					oImg.set('has_apply_template', true);
					oImg.set('selectable', false);
					canvas.insertAt(oImg, 1);
					canvas.renderAll();
				});	
	
				v.remove();
				canvas.renderAll();
				
				return false;
			}
			//console.log('left=' + v.left + ' top=' + v.top + 'currentWidth='+ v.currentWidth + 'currentWidth=' + v.currentHeight);
		}
	});
	
	if(apply_template == false){
		////console.log('event: ', e);
		var id = date.getTime();
		past_width = img.width;
		past_height = img.height;
		past_top = img.top;
		past_left = img.left;
		past_scaleX = 1;
		past_scaleY = 1;
		newImage = new fabric.Image(img, {
			id: id,
			width: img.width,
			height: img.height,
			left: e.layerX,
			top: e.layerY,
			filename: img.src,
			has_effect_for_mask: false,
			clipName: id,
			output_pass: false,
			always_on_top: false,
			isdelete: 'N',
			originX: 'left',
			originY: 'top'
		});
		canvas.add(newImage);
		//adjust_layer();
		var o = canvas.getObjects();
		canvas.setActiveObject(o[o.length-1]);
		isnewobject = true;
		record_step('initial');
		record_step('新增物件');
		add_layer();
		update_property_block();
		total_objects++;
		return false;
	}
}

function handleDragEnd(e) {
    [ ].forEach.call(drag_images, function (img) {
        img.classList.remove('img_dragging');
    });
}

function sendto_template(img, o){
	template_image = o.getSrc(); 
	var temp_div = document.createElement('canvas');
	temp_div.width = o.currentWidth;
	temp_div.height = o.currentHeight;
	var context = temp_div.getContext('2d');
	var template_mask = document.createElement('img');
	template_mask.src = template_image;
	var template_data = document.createElement('img');
	template_data.src = img;
	context.drawImage(template_mask,0,0,temp_div.width, temp_div.height);
	context.globalCompositeOperation = 'source-in';
	context.drawImage(template_data,0,0,temp_div.width, temp_div.height);
	return temp_div;
};
function raise_drop_function(){

	if (Modernizr.draganddrop) {
		
		[ ].forEach.call(drag_images, function (img) {
			img.addEventListener('dragstart', handleDragStart, false);
			img.addEventListener('dragend', handleDragEnd, false);
		});
		
		canvasContainer.addEventListener('dragenter', handleDragEnter, false);
		canvasContainer.addEventListener('dragover', handleDragOver, false);
		canvasContainer.addEventListener('dragleave', handleDragLeave, false);
		canvasContainer.addEventListener('drop', handleDrop, false);
        } else {
		alert("This browser doesn't support the HTML5 Drag and Drop API.");
	};
};

function get_preview_image(){
	$.getJSON('HandlerPainter.ashx?action=get_upload_photo',{'type':'preview','painter_id':painter_id,'order_detail_id':order_detail_id}, function(data){
		$.each(data,function(k,v){
			d = new Date();
			cacheid = d.getTime();
            //console.log('v.img_path = ' + v.img_path + 'v.page_id=' + v.page_id);
			//$("#pages_list > div:eq("+parseInt(v.page_id)+")").find("img").attr('src','painter/images/page.png');
			$("#pages_list > div:eq("+parseInt(v.page_id)+")").find("img").attr('src',v.img_path+'?'+cacheid);
		});
	});
};
function get_template_preview_image(){
	$("#pages_list").html('');
	for(var i=0;i<user_add_painter_pages;i++){
		var p = '<div id="pageid_'+i+'">'+
			'<table>'+
			'<tr><td><img onclick="exchange_template_pages('+(i)+')" style="cursor:pointer;background-color:#ffffff;" src="painter/images/page.png" width="90" border="1"></td></tr>'+
			'<tr><td align="center">['+(i)+']</td></tr>'+
			'</table>'+
			'</div>';
		//console.log(p);
		$("#pages_list").append(p);
	};
	
	$.getJSON('HandlerPainter.ashx?action=get_upload_photo',{'type':'template_preview', 'painter_id':painter_id}, function(data){
		$.each(data,function(k,v){
			d = new Date();
			cacheid = d.getTime();
            //console.log('v.img_path = ' + v.img_path + 'v.page_id=' + v.page_id);
			//$("#pages_list > div:eq("+parseInt(v.page_id)+")").find("img").attr('src','painter/images/page.png');
			$("#pages_list > div:eq("+parseInt(v.page_id)+")").find("img").attr('src',v.img_path+'?'+cacheid);
		});
		
	});
};

var oStyle = document.createElement('style');
document.getElementsByTagName('head')[0].appendChild(oStyle);
function get_material_filepath(){
    
	$.getJSON('HandlerPainter.ashx?action=get_material_filepath',{}, function(data){
        var d = JSON.parse(data.message);
        $("#background_page").html('<span id="apply_background_btn">套用</span>');
        $("#mask_page").html('<span id="open_mask_btn">進階</span><span id="apply_mask_btn">直接套用</span>');
        
		$.each(d.bg_list,function(k,v){
			filename = v.bg_path.split('/');
            filename = filename[filename.length-1];
			resize = calculate_image_size(v.width, v.height);
			var p = '<img width="'+resize[0]+'" height="'+resize[1]+'" src="'+v.bg_path+'" onmouseover="move_background_apply_btn($(this).position(), this.src);"><br/>'+filename;
			$("#background_page").append(p);
		});
		$.each(d.mt_list,function(k,v){
			filename = v.mt_path.split('/');
            filename = filename[filename.length-1];
			resize = calculate_image_size(v.width, v.height);
			var p = '<img draggable="true" width="'+resize[0]+'" height="'+resize[1]+'" src="..' + v.mt_path + '"><br/>'+filename;
			$("#material_page").append(p);
		});
		$.each(d.mask_list,function(k,v){
			filename = v.mask_path.split('/');
            filename = filename[filename.length-1];
			resize = calculate_image_size(v.width, v.height);
			var p = '<img draggable="true" width="'+resize[0]+'" height="'+resize[1]+'" src="..' + v.mask_path + '" onmouseover="move_mask_apply_btn($(this).position(), this.src, this.width, this.height);"><br/>'+filename;
			$("#mask_page").append(p);
		});
        
        var fonts = new Array();
        $.each(d.font_list,function(k,v){
            var font_name = v.font_path.split(".");
            font_name2 = font_name[0].split("/");
            font_name = font_name2[font_name2.length-1];
            fonts.push(font_name+","+font_name);
            var append_style = '@font-face {  font-family: "'+font_name+'";  src: url('+v.font_path+')}';
            oStyle.textContent += append_style;
		});
        
        if($('#fontSelect').find('span').length == 0){
			fonts.push('Flavors,Flavors');
			fonts.push('UnifrakturMaguntia,UnifrakturMaguntia');
			fonts.push('Hanalei,Hanalei');
			fonts.push('Pinyon Script,Pinyon Script');
			fonts.push('Arial,Arial');
			fonts.push('Arial Black,Arial Black');
			fonts.push('Courier New,Courier New');
			fonts.push('Times New Roman,Times New Roman');
			fonts.push('Verdana,Verdana');
			
			$('#fontSelect').fontSelector({
			'hide_fallbacks': true,
			'initial': 'Courier New',
			'selected': function (style) {
				active_font = style;
			},
			'fonts': fonts
			});
		}
    
        drag_images = document.querySelectorAll('.support_drag img');
        canvasContainer = document.getElementById('mycanvas_base');
		raise_drop_function();
	});

};
function get_template_material_filepath(){
        
	$.getJSON('HandlerPainter.ashx?action=get_material_filepath',{}, function(data){
        var d = JSON.parse(data.message);      
		$.each(d.tmpMask_list,function(k,v){
			filename = v.tmpMask_path.split('/');
            filename = filename[filename.length-1];
			resize = calculate_image_size(v.width, v.height);
            if(location.pathname == '/doitwell02/painter_template.html')
			    var p = '<img draggable="true" height="60" style="padding-right:5px;" src="' + v.tmpMask_path + '">';
            else
                var p = '<img draggable="true" height="60" style="padding-right:5px;" src="..' + v.tmpMask_path.replace("/doitwell02","") + '">';

			$("#NewPage_Detail").append(p);
		});    
        drag_images = document.querySelectorAll('.support_drag img');
        canvasContainer = document.getElementById('mycanvas_base');
		raise_drop_function();
	});

};
function close_mask_block(){
    $("#mask_block").hide();
};

function calculate_image_size(w,h){
	var max_width = 140;
	rate = max_width / w;
	re_width = w * rate;
	re_height = h * rate;
	return [re_width, re_height];
};


var image_loaded_completed = false;
function get_photos_page(){
    var total_images_in_photos_page = 0;
    
    var c = url.parse(location.search);
    if(order_detail_id == undefined)
        order_detail_id = c.get.order_detail_id;
    if(painter_id == undefined)
        painter_id = c.get.painter_id;
    
	$.getJSON('HandlerPainter.ashx?action=get_upload_photo',{'type':'user','order_detail_id':order_detail_id,'painter_id':painter_id}, function(data){
        $("#photos_page").html('<button id="open_upload_albums_btn" type="button" onclick="open_upload_albums()">上傳檔案</button>');
		$.each(data,function(k,v){
			setTimeout(function (){
				//console.log('delay');
			},3000);
            total_images_in_photos_page++;
            filename = v.img_path.split('/');
            ////console.log(filename);
            filename = filename[filename.length-1];
			resize = calculate_image_size(v.width, v.height);
			var p = '<img draggable="true" width="'+resize[0]+'" height="'+resize[1]+'" src="'+v.img_path+'" ><br/>'+filename;
			$("#photos_page").append(p);
		});
		$("#open_upload_albums_btn").button();
        //clear_drop_function();
        
        var loaded_image = 0;
        $("#photos_page img").load(function(){
            loaded_image++;
            
            if(loaded_image == total_images_in_photos_page)
                image_loaded_completed = true;
                
                //Trigger thr function when all images are load completed.
                get_work_list();
        });
        
        if(total_images_in_photos_page == 0){
            image_loaded_completed = true;
            get_work_list();
        };
        
        drag_images = document.querySelectorAll('.support_drag img');
        canvasContainer = document.getElementById('mycanvas_base');
		raise_drop_function();
	});
};

$(document).ready(function(){
	if (location.pathname == '/painter.html' || location.pathname == '/doitwell02/painter.html'){
		$("body").css("overflow", "hidden");
		var activate_detail;
		get_photos_page();
		$("#page_number").html('[1]').css({width: display_width+60});   //Plus + 60; because customer want page number can align to middle.
		$("#start_upload_btn").button();    
		show_init_box();
	};
	
	if (location.pathname == '/painter_template.html' || location.pathname == '/doitwell02/painter_template.html'){
		$("#mycanvas_base").css({'width': (screen.width - 50) ,'height':(screen.height - 400) ,'overflow-x':'scroll','overflow-y':'scroll'});
		get_template_material_filepath();
		TemplateNewPage();
		get_product_data();
		$("#page_number").html('[1]').css({width: display_width});
	};
    
});

function get_product_data(){
	$.getJSON('HandlerPainter.ashx?action=get_prod_list',{}, function(data){
		var Category = new Object();
		if (data){
			Category.category = new Array();
			$.each(data, function(k,v){
				if (Category.category.indexOf(v.category) == -1){
					Category.category.push(v.category);
					$("#category").append('<option value="'+v.category+'">'+v.category+'</option>');
				};
			});
			
		};
	});
};
function get_spec_data(){
	$.getJSON('HandlerPainter.ashx?action=get_prod_list',{}, function(data){
		if (data){
			var spec = new Array();
			$("#spec").html('<option value="">=請選擇=</option>');
			product_spec = undefined;
			$.each(data, function(k,v){
				if (v.category == $("#category").val() )
					if (spec.indexOf(v.spec) == -1){
						product_type = $("#category").val();
						spec.push(v.spec);
						$("#spec").append('<option value="'+v.spec+'" data-width="'+v.width+'" data-height="'+v.height+'" data-bleed-width="'+v.bleed_width+'" data-bleed-height="'+v.bleed_height+'" data-prodid="'+v.prod_id+'">'+v.spec+'</option>');
					};
			});
			
		};
	});
};

function get_pages(){
	$.getJSON('HandlerPainter.ashx?action=get_pages',{'prod_id':prod_id,'painter_id':painter_id}, function(data){
		if(data.message){
			user_add_painter_pages = parseInt(data.message);
			get_template_preview_image();
		}
		
	});
};

function set_template(template_image){
	apply_template_record[page_id] = template_image;
	canvas.setOverlayImage(apply_template_record[page_id], canvas.renderAll.bind(canvas));
	
};
function set_spec_data_painter(){
	zoomout_count = 1;
	display_width = parseFloat($("#spec option:selected").data('width')) * 37.79;
	display_height = parseFloat($("#spec option:selected").data('height')) * 37.79;
	
	bleed_width = parseFloat($("#spec option:selected").data('bleed-width')) * 37.79;
	bleed_height = parseFloat($("#spec option:selected").data('bleed-height')) * 37.79;
	//console.log('bleed_width :' + bleed_width);
	//console.log('bleed_height :' + bleed_height);
	
	var _display_width = display_width-18;
	var _display_height = display_height-18;
	
	canvas.setWidth(_display_width);
	canvas.setHeight(_display_height);
	canvas.renderAll()
	draw_middle_line();
	real_output_area.setScaleX(1);
	real_output_area.setScaleY(1);
	real_output_area.setWidth(bleed_width);
	real_output_area.setHeight(bleed_height);
	real_output_area.setLeft(_display_width / 2);
	real_output_area.setTop(_display_height / 2);
	canvas.renderAll();

	$("#mycanvas_base").css({'width': (screen.width - 380) ,'height':(screen.height - 370) ,'overflow-x':'scroll','overflow-y':'scroll'});
	$("#page_number").html('[1]').css({width: display_width});
	
	
};

function set_spec_data(){
	zoomout_count = 1;
	display_width = parseFloat($("#spec option:selected").data('width')) * 37.79;
	display_height = parseFloat($("#spec option:selected").data('height')) * 37.79;
	
	bleed_width = parseFloat($("#spec option:selected").data('bleed-width')) * 37.79;
	bleed_height = parseFloat($("#spec option:selected").data('bleed-height')) * 37.79;
	//console.log('bleed_width :' + bleed_width);
	//console.log('bleed_height :' + bleed_height);
	
	var _display_width = display_width-18;
	var _display_height = display_height-18;
	
	canvas.setWidth(_display_width);
	canvas.setHeight(_display_height);
	canvas.renderAll()
	draw_middle_line();
	real_output_area.setScaleX(1);
	real_output_area.setScaleY(1);
	real_output_area.setWidth(bleed_width);
	real_output_area.setHeight(bleed_height);
	real_output_area.setLeft(_display_width / 2);
	real_output_area.setTop(_display_height / 2);
	canvas.renderAll();

	$("#mycanvas_base").css({'width': (screen.width - 50) ,'height':(screen.height - 400) ,'overflow-x':'scroll','overflow-y':'scroll'});
	$("#page_number").html('[1]').css({width: display_width});
	painter_id = $("#spec option:selected").data('prodid');
	prod_id = $("#spec option:selected").data('prodid');
	product_spec = $("#spec").val();
	//get how many pages for this painter
	get_pages();
	
	//load before save data.
	clear_painter();
	read_before_template_save_data('remote');	
	
};
function adjust_painter_zoom(){
	if($("#category").val() == "無框畫"){
	zoomOut();
	zoomOut();
	zoomOut();
	};
};

function delete_template(p){
	v = canvas._objects;
	for(var i = 0; i < v.length; i++){
		if(v[i].istemplate == true || v[i].istemplate == 'true'){
			v[i].isdelete="Y";
			v[i].visible=false;
		};
	}
	canvas.renderAll();
};
function read_template(position, p){
	if(position == 'del'){
		delete_template(page_id);
	}
	if(position == 'local'){
		delete_template(page_id);
		db.transaction(function(d){
			//console.log('select * from painter_template_save where painter_id="'+prod_id+'" and page_id="'+page_id+'" order by layer_index asc;');
			d.executeSql('select * from painter_template_save where painter_id="'+prod_id+'" and page_id="'+p+'" order by layer_index asc;', [], function(tx, results){
				if(results.rows.length > 0){
					//var o = results.rows.item(0);
					for (i = 0; i < results.rows.length; i++){				
						//console.log(results.rows.item(i));
						put_template_objects_on_painter(results.rows.item(i));
					};
					canvas.renderAll();	
					
				}
				
				
			});
		});
	};
};
function read_before_template_save_data(position){
	if(position == 'remote'){
		var json = {};
		json.painter_id = painter_id;
		json.page_id = page_id;
		var json = jQuery.parseJSON(JSON.stringify(json));
		$.ajax({
			type: 'POST',
			dataType: "json",
			url: 'HandlerPainter.ashx?action=read_before_save_data&type=template',
			data: json,
			success: function (data) {
				if(data.message){
					rows = jQuery.parseJSON(data.message);
					$.each(rows, function(k,v){
						put_objects_on_painter(v);
					});
				}
			}
		});	
	};
	if(position == 'local'){
		db.transaction(function(d){
			//console.log('select * from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;');
			d.executeSql('select * from painter_template_save where painter_id="'+painter_id+'" and page_id="'+page_id+'" order by layer_index asc;', [], function(tx, results){
				if(results.rows.length > 0){
					//var o = results.rows.item(0);
					for (i = 0; i < results.rows.length; i++){				
						//console.log(results.rows.item(i));
						put_objects_on_painter(results.rows.item(i));
					};
					canvas.renderAll();	
					
				}
				
				
			});
		});
	};
	return setTimeout("adjust_painter_zoom()", 1000 );
};

function open_upload_albums(){
    var upload_dialog = $("#upload_dialog");
	var progress = document.querySelector('.percent');
	
    upload_dialog.dialog({width: 450}).css({'font-size':'12px'}).on( "dialogclose", function( event, ui ) {
        get_photos_page();
    } );
	
	$("#leave_upload_image_btn").click(function(){
		upload_dialog.dialog('close');
		get_photos_page();
	});
	
	$("#myfiles").on("change", function (event){
		var upload_images = document.getElementById('myfiles').files;
        
                
		$("#upload_status").html('');
		$.each(upload_images, function(k,v){
            
			$("#upload_status").append((k+1)+'. ' + v.name+', '+ Math.round(v.size/1024)+'K <br/>');
		});
	});
	
	function updateProgress(evt) {
		if (evt.lengthComputable) {
			var percentLoaded = Math.round((evt.loaded / evt.total) * 100);
			if (percentLoaded < 100) {
				progress.style.width = percentLoaded + '%';
				progress.textContent = percentLoaded + '%';
				
			};
		};
	};
    $("#start_upload_image_btn").unbind();
	$("#start_upload_image_btn").click(function(){
		var upload_images = document.getElementById('myfiles').files;
		
		
		$.each(upload_images ,function(index, file){
		var reader = new FileReader();
		
		reader.onprogress = updateProgress;
		
		var data = reader.readAsDataURL(file);
		reader.onload = (function (element) {
			//console.log(element.target.result);

			var json = {};
			json.type = 'user';
			json.order_detail_id = order_detail_id;
			json.painter_id = painter_id;
			json.page_id = page_id;
			json.user_id = session_id;
			json.user_name = session_name;
			json.filename = file.name;
			json.data = element.target.result;
            //console.log(json);
            
			var json = jQuery.parseJSON(JSON.stringify(json));
			$.ajax({
				type: 'POST',
				dataType: "json",
				url: 'HandlerPainter.ashx?action=upload_image',
				data: json,
				success: function (data) {
                    //console.log(data);
                    if (data.id == '999')
                        alert(data.message);
				}
			});
			
			
			
			setTimeout("get_photos_page();document.getElementById('progress_bar').className='';", 5000);
            progress.style.width = '100%';
			progress.textContent = '100%';
	  
		});
		reader.onloadend = function(){
			get_photos_page();
			
		};
		reader.onloadstart = function(e) {
			document.getElementById('progress_bar').className = 'loading';
		};
		});
		
		
	});
	
	
	/*
	$("#start_upload_image_btn").click(function(){
		$("#myfiles").unbind();
		$("#myfiles").on("change", function (event) {
				//console.log(event.target.files);
			if (event.target.files.length > 0) {
				$.each(event.target.files, function(index, file) {
					var reader = new FileReader();
					var data = reader.readAsDataURL(file);
					console.log(file.name);
					reader.onload = (function (element) {
						console.log(element.target.files);
						
						var json = {};
						json.type = 'user';
						json.order_detail_id = order_detail_id;
						json.painter_id = painter_id;
						json.page_id = page_id;
						json.user_id = session_id;
						json.user_name = session_name;
						json.filename = file.name;
						json.data = element.target.result;
						var json = jQuery.parseJSON(JSON.stringify(json));
						$.ajax({
							type: 'POST',
							dataType: "json",
							url: 'HandlerPainter.ashx?action=upload_image',
							data: json,
							success: function (data) {
							}
						});
						
						$("#upload_status").html('已完成');
						
					});
					reader.onloadstart = function(e) {
						$("#upload_status").html('檔案上傳中...');
					};
				});
				
			}
			return false;
		});    	
	});
	
	*/

};

function image_filter_brightness(val, want_record){
	var o = canvas.getActiveObject();
	o.filters.push(new fabric.Image.filters.Brightness({ brightness: val }));
	o.use_filters = 'Brightness';
	o.use_filters_val = val;
	o.applyFilters(canvas.renderAll.bind(canvas));
    brightness_value = val;
	if (want_record == undefined){
		record_step("Brightness");
		//record_step("Brightness");
	}
    close_image_filters();
};

function image_filter_blur(want_record){
	var o = canvas.getActiveObject();
	o = canvas.getActiveObject();
	o.filters.push(new fabric.Image.filters.Convolute({
		matrix: [ 0.0029690167439506495, 0.013306209891014003, 0.021938231279715035, 0.013306209891014003, 0.0029690167439506495, 
				  0.013306209891014003, 0.059634295436180214, 0.09832033134884507, 0.059634295436180214, 0.013306209891014003, 
				  0.021938231279715035, 0.09832033134884507, 0.16210282163712414, 0.09832033134884507, 0.021938231279715035, 
				  0.013306209891014003, 0.059634295436180214, 0.09832033134884507, 0.059634295436180214, 0.013306209891014003, 
				  0.0029690167439506495, 0.013306209891014003, 0.021938231279715035, 0.013306209891014003, 0.0029690167439506495,  ]
	}));
	o.use_filters = 'Blur';
	o.applyFilters(canvas.renderAll.bind(canvas));
	if (want_record == undefined){
		record_step("Blur");
		//record_step("Blur");
	}
    close_image_filters();
};

function image_filter_sharpen(want_record){
	var o = canvas.getActiveObject();
	o.filters.push(new fabric.Image.filters.Convolute({
		matrix: [ 0, -1,  0,
				  -1,  5, -1,
				   0, -1,  0 
				  ]
	}));
	o.use_filters = 'Sharpen';
	o.applyFilters(canvas.renderAll.bind(canvas));
	if (want_record == undefined){
		record_step("Sharpen");
		//record_step("Sharpen");
	}
    close_image_filters();
};

function image_filter_opacity(val, want_record){
	var o = canvas.getActiveObject();
	o.set({opacity:val});
	canvas.renderAll();
    opacity_value = val;
    o.use_filters = 'Opacity';
	o.use_filters_val = val;
	if (want_record == undefined){
		record_step("Opacity");
		//record_step("Opacity");
	}
    close_image_filters();
};

function image_filter_emboss(want_record){
	var o = canvas.getActiveObject();
	o.filters.push(new fabric.Image.filters.Convolute({
		matrix: [ 1,   1,  1,
				  1, 0.7, -1,
				 -1,  -1, -1
				  ]
	}));
	o.use_filters = 'Emboss';
	o.applyFilters(canvas.renderAll.bind(canvas));
	if (want_record == undefined){
		record_step("Emboss");
		//record_step("Emboss");
	}
    close_image_filters();
};

function image_filter_sepia(want_record){
	var o = canvas.getActiveObject();
	o.filters.push(new fabric.Image.filters.Sepia2());
	o.use_filters = 'Sepia';
	o.applyFilters(canvas.renderAll.bind(canvas));
	if (want_record == undefined){
		record_step("Sepia");
		//record_step("Sepia");
	}
    close_image_filters();
};

var ifb_x,ifb_y;
var ifb_press = false;
$("#image_filters_block").mousedown(function(e){
    ifb_press = true;
    $(this).mousemove(function(e){
        ifb_x = e.clientX;
        ifb_y = e.clientY;
        ////console.log(ifb_x + ' ' + ifb_y);
        if(ifb_press == true)
            $("#image_filters_block").css({'left':ifb_x-480,'top':ifb_y-185})
    }).mouseup(function(e){
        ifb_press = false;
    });
});
/*
var msb_x,msb_y;
var msb_press = false;
$("#mask_block").mousedown(function(e){
    msb_press = true;
    $(this).mousemove(function(e){
        msb_x = e.clientX;
        msb_y = e.clientY;
        if(msb_press == true)
            $("#mask_block").css({'left':msb_x-480,'top':msb_y-185})
    }).mouseup(function(e){
        msb_press = false;
    });
});
*/

$('#colorSelector').ColorPicker({
	color: '#000000',
	onShow: function (colpkr) {
		$(colpkr).fadeIn(500);
		return false;
	},
	onHide: function (colpkr) {
		$(colpkr).fadeOut(500);
		return false;
	},
	onChange: function (hsb, hex, rgb) {
		fontColor = '#' + hex;
		$('#colorSelector div').css('backgroundColor', '#' + hex);
	}
});
$('#StrokecolorSelector').ColorPicker({
	color: '#000000',
	onShow: function (colpkr) {
		$(colpkr).fadeIn(500);
		return false;
	},
	onHide: function (colpkr) {
		$(colpkr).fadeOut(500);
		return false;
	},
	onChange: function (hsb, hex, rgb) {
		fontStrokeColor = '#' + hex;
		$('#StrokecolorSelector div').css('backgroundColor', '#' + hex);
	}
});

$("#fontStrokeWidthSlider").slider({
  min: 1,
  max: 10,
  value: 1,
  slide: function( event, ui ) {
	$( "#fontStrokeWidth" ).val( ui.value );
  }
});
$( "#fontStrokeWidth" ).val( $( "#fontStrokeWidthSlider" ).slider( "value" ) );

function set_font_style(style){
	if(fontStyle != undefined)
		$("#"+fontStyle).css({'background-color':'#cccccc'});
	fontStyle = style;
	$("#"+style).css({'background-color':'#333333'});
};

$("#property_shadow").change(function(){
	if($("#property_shadow:checked").val() == "Y"){
		var o = canvas.getActiveObject();
		o.textShadow = 'rgba(0,0,0,0.3) 5px 5px 5px';
	}else{
		var o = canvas.getActiveObject();
		o.textShadow = '';
	}
	canvas.renderAll();
});

$("#property_opacity").change(function(){
	var o = canvas.getActiveObject();
	o.opacity = parseFloat($("#property_opacity").val());
	canvas.renderAll();
});