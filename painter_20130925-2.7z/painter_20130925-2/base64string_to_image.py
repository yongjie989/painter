import base64
f = file('e:\\1.png', 'r')
fs = f.read()
f.close()

f = file('e:\\2.png', 'wb')
f.write(base64.decodestring(fs))
f.close()
